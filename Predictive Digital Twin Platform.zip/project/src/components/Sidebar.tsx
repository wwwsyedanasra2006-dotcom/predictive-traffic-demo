import {
  LayoutDashboard,
  Map,
  Car,
  Zap,
  Droplets,
  SlidersHorizontal,
  ShieldAlert,
  FlaskConical,
  History,
  BarChart3,
  Settings,
  Moon,
  Sun,
  Activity,
} from 'lucide-react';
import type { PageId } from '@/lib/types';
import { useTheme } from '@/hooks/useTheme';

interface SidebarProps {
  currentPage: PageId;
  onNavigate: (page: PageId) => void;
  isOpen: boolean;
  onClose: () => void;
}

const NAV_ITEMS: { id: PageId; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'overview', label: 'Overview', icon: LayoutDashboard },
  { id: 'digital-twin', label: 'Digital Twin', icon: Map },
  { id: 'traffic', label: 'Traffic Intelligence', icon: Car },
  { id: 'energy', label: 'Energy Intelligence', icon: Zap },
  { id: 'water', label: 'Water Intelligence', icon: Droplets },
  { id: 'what-if', label: 'What-If Simulator', icon: SlidersHorizontal },
  { id: 'risk', label: 'Risk Center', icon: ShieldAlert },
  { id: 'optimization', label: 'Optimization Lab', icon: FlaskConical },
  { id: 'history', label: 'Simulation History', icon: History },
  { id: 'evaluation', label: 'Model Evaluation', icon: BarChart3 },
  { id: 'settings', label: 'Settings', icon: Settings },
];

export function Sidebar({ currentPage, onNavigate, isOpen, onClose }: SidebarProps) {
  const { theme, toggleTheme } = useTheme();

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 md:hidden" onClick={onClose} />
      )}
      <aside
        className={`mirage-sidebar fixed md:static z-40 h-full w-64 flex flex-col transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="flex items-center gap-2.5 px-5 py-5 border-b border-slate-200/60 dark:border-slate-700/60">
          <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-sky-400 to-cyan-600 flex items-center justify-center">
            <Activity className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-wide">MIRAGE</h1>
            <p className="text-[10px] mirage-text-muted tracking-wider">DIGITAL TWIN</p>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto mirage-scrollbar px-3 py-4 space-y-0.5">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onClose();
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-200 ${
                  active
                    ? 'bg-sky-500/10 text-sky-600 dark:text-sky-400'
                    : 'mirage-text-muted hover:bg-slate-100 dark:hover:bg-slate-800/50'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="px-3 py-4 border-t border-slate-200/60 dark:border-slate-700/60">
          <button
            onClick={toggleTheme}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium mirage-text-muted hover:bg-slate-100 dark:hover:bg-slate-800/50 transition-colors"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            <span>{theme === 'dark' ? 'Light Mode' : 'Dark Mode'}</span>
          </button>
        </div>
      </aside>
    </>
  );
}

export type { PageId };
