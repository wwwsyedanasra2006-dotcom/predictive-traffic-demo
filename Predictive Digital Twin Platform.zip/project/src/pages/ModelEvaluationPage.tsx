import { useMemo, useState } from 'react';
import { Card, StatCard, SectionHeader, Button } from '@/components/ui';
import { evaluateTrafficModel, evaluateEnergyModel, evaluateWaterModel } from '@/lib/predictions';
import type { ModelMetrics } from '@/lib/types';
import { BarChart3, Brain, TrendingUp, Download } from 'lucide-react';
import { exportParamsCSV, downloadCSV } from '@/lib/export';
import { DEFAULT_SCENARIO } from '@/lib/simulationEngine';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend, ScatterChart, Scatter, Line, LineChart } from 'recharts';

type ModuleKey = 'traffic' | 'energy' | 'water';

export function ModelEvaluationPage() {
  const [activeModule, setActiveModule] = useState<ModuleKey>('traffic');

  const metrics: Record<ModuleKey, ModelMetrics> = useMemo(() => ({
    traffic: evaluateTrafficModel(),
    energy: evaluateEnergyModel(),
    water: evaluateWaterModel(),
  }), []);

  const m = metrics[activeModule];
  const isDark = document.documentElement.classList.contains('dark');
  const gridColor = isDark ? '#1e293b' : '#e2e8f0';
  const tickColor = isDark ? '#94a3b8' : '#64748b';
  const tooltipStyle = { background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 };

  const importanceData = m.featureImportance.slice(0, 8).map((f) => ({ feature: f.feature, importance: Math.round(f.importance * 1000) / 10 }));
  const metricsComparison = [
    { metric: 'MAE', model: m.mae, baseline: m.baselineMae },
    { metric: 'RMSE', model: m.rmse, baseline: m.baselineRmse },
    { metric: 'R²', model: m.r2, baseline: m.baselineR2 },
  ];
  const scatterData = m.actualVsPredicted.map((d) => ({ actual: d.actual, predicted: d.predicted, baseline: d.baseline }));
  const identityLine = m.actualVsPredicted.map((d) => ({ x: d.actual, y: d.actual }));

  function handleExport() {
    const lines: string[] = [];
    lines.push(`MODEL EVALUATION REPORT - ${activeModule.toUpperCase()}`);
    lines.push(`Model: ${m.modelName}`);
    lines.push(`Baseline: ${m.baselineName}`);
    lines.push(`Train size: ${m.trainSize}, Test size: ${m.testSize}`);
    lines.push('');
    lines.push('METRIC,MODEL,BASELINE');
    lines.push(`MAE,${m.mae},${m.baselineMae}`);
    lines.push(`RMSE,${m.rmse},${m.baselineRmse}`);
    lines.push(`R2,${m.r2},${m.baselineR2}`);
    lines.push('');
    lines.push('FEATURE,IMPORTANCE');
    m.featureImportance.forEach((f) => lines.push(`${f.feature},${f.importance}`));
    lines.push('');
    lines.push('ACTUAL,PREDICTED,BASELINE');
    m.actualVsPredicted.forEach((d) => lines.push(`${d.actual},${d.predicted},${d.baseline}`));
    downloadCSV(lines.join('\n'), `mirage_model_evaluation_${activeModule}.csv`);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Model Evaluation</h1>
          <p className="text-sm mirage-text-muted">Held-out test metrics, feature importance, and baseline comparison from actual model runs</p>
        </div>
        <Button variant="secondary" size="sm" onClick={handleExport}>
          <span className="flex items-center gap-1.5"><Download className="w-3.5 h-3.5" /> Export Metrics</span>
        </Button>
      </div>

      <Card>
        <div className="flex gap-2">
          {(['traffic', 'energy', 'water'] as ModuleKey[]).map((mod) => (
            <button
              key={mod}
              onClick={() => setActiveModule(mod)}
              className={`px-4 py-2 rounded-lg text-sm font-medium capitalize transition-all ${activeModule === mod ? 'bg-sky-500 text-white' : 'mirage-surface'}`}
            >
              {mod}
            </button>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Model MAE" value={m.mae.toFixed(4)} icon={<BarChart3 className="w-5 h-5" />} accentColor="#0ea5e9" subValue={`Baseline: ${m.baselineMae.toFixed(4)}`} />
        <StatCard label="Model RMSE" value={m.rmse.toFixed(4)} icon={<BarChart3 className="w-5 h-5" />} accentColor="#f59e0b" subValue={`Baseline: ${m.baselineRmse.toFixed(4)}`} />
        <StatCard label="Model R²" value={m.r2.toFixed(4)} icon={<TrendingUp className="w-5 h-5" />} accentColor="#10b981" subValue={`Baseline: ${m.baselineR2.toFixed(4)}`} />
        <StatCard label="Train/Test Size" value={`${m.trainSize}/${m.testSize}`} icon={<Brain className="w-5 h-5" />} accentColor="#8b5cf6" subValue="chronological split" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <SectionHeader title="Model vs Baseline" subtitle="Lower MAE/RMSE is better, higher R² is better" icon={<BarChart3 className="w-5 h-5" />} />
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={metricsComparison}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis dataKey="metric" tick={{ fontSize: 11, fill: tickColor }} />
              <YAxis tick={{ fontSize: 10, fill: tickColor }} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="model" fill="#0ea5e9" name="Random Forest" radius={[4, 4, 0, 0]} />
              <Bar dataKey="baseline" fill="#94a3b8" name="Baseline" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <SectionHeader title="Feature Importance" subtitle="Ranked by measured contribution in the Random Forest" icon={<Brain className="w-5 h-5" />} />
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={importanceData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis type="number" tick={{ fontSize: 10, fill: tickColor }} />
              <YAxis type="category" dataKey="feature" tick={{ fontSize: 10, fill: tickColor }} width={110} />
              <Tooltip contentStyle={tooltipStyle} />
              <Bar dataKey="importance" fill="#0ea5e9" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <Card>
        <SectionHeader title="Actual vs Predicted" subtitle="First 60 test samples — closer to the diagonal line is better" icon={<TrendingUp className="w-5 h-5" />} />
        <ResponsiveContainer width="100%" height={320}>
          <ScatterChart>
            <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
            <XAxis type="number" dataKey="actual" name="Actual" tick={{ fontSize: 10, fill: tickColor }} />
            <YAxis type="number" dataKey="predicted" name="Predicted" tick={{ fontSize: 10, fill: tickColor }} />
            <Tooltip contentStyle={tooltipStyle} cursor={{ strokeDasharray: '3 3' }} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            <Scatter name="Model Predictions" data={scatterData} fill="#0ea5e9" />
          </ScatterChart>
        </ResponsiveContainer>
      </Card>

      <Card>
        <SectionHeader title="Model Details" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800/50">
            <p className="font-semibold mb-1">Model</p>
            <p className="mirage-text-muted">{m.modelName}</p>
          </div>
          <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800/50">
            <p className="font-semibold mb-1">Baseline</p>
            <p className="mirage-text-muted">{m.baselineName}</p>
          </div>
          <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800/50">
            <p className="font-semibold mb-1">Features ({m.featureNames.length})</p>
            <p className="mirage-text-muted text-xs">{m.featureNames.join(', ')}</p>
          </div>
          <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800/50">
            <p className="font-semibold mb-1">Data Split</p>
            <p className="mirage-text-muted">Chronological 80/20 — {m.trainSize} training, {m.testSize} test samples</p>
          </div>
        </div>
      </Card>

      <Card>
        <SectionHeader title="Limitations" />
        <div className="p-4 rounded-lg bg-amber-500/5 border border-amber-500/20">
          <ul className="text-sm space-y-2">
            <li>• All training data is synthetic, generated with controlled randomness and documented assumptions. Strong performance on synthetic data does not establish real-world predictive accuracy.</li>
            <li>• The Random Forest uses 15 trees with max depth 7 — suitable for a research prototype but not production-scale.</li>
            <li>• The baseline is a historical average grouped by key features (zone, weather, zone type). It provides a simple comparison point, not a state-of-the-art baseline.</li>
            <li>• Time-aware chronological splitting prevents data leakage but limits the test set to the final 20% of the time series.</li>
            <li>• Feature importance is derived from variance reduction in tree splits, not permutation importance, and may differ for correlated features.</li>
          </ul>
        </div>
      </Card>
    </div>
  );
}
