import { useMemo } from 'react';
import { Card, StatCard, RiskBadge, SectionHeader, ProgressBar } from '@/components/ui';
import { getDashboardSummary } from '@/lib/dashboardSummary';
import { ZONES, ZONE_TYPE_COLORS, zoneTypeLabel } from '@/lib/zones';
import { Car, Zap, Droplets, ShieldAlert, AlertTriangle, Activity, MapPin } from 'lucide-react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from 'recharts';
import { predictTraffic, predictEnergy, predictWater } from '@/lib/predictions';
import { DEFAULT_SCENARIO } from '@/lib/simulationEngine';

export function OverviewPage() {
  const summary = useMemo(() => getDashboardSummary(), []);
  const trafficData = useMemo(() => predictTraffic(DEFAULT_SCENARIO, 12), []);
  const energyData = useMemo(() => predictEnergy(DEFAULT_SCENARIO, 12), []);
  const waterData = useMemo(() => predictWater(DEFAULT_SCENARIO, 12), []);

  const trafficChart = trafficData[0]?.forecast.map((f) => ({ hour: `${f.hour}:00`, congestion: f.value })) || [];
  const energyChart = energyData[0]?.forecast.map((f) => ({ hour: `${f.hour}:00`, demand: f.demand, supply: f.supply })) || [];
  const waterChart = waterData[0]?.forecast.map((f) => ({ hour: `${f.hour}:00`, demand: f.demand, supply: f.supply })) || [];

  const zoneBarData = ZONES.map((z) => {
    const t = trafficData.find((p) => p.zoneId === z.id);
    const e = energyData.find((p) => p.zoneId === z.id);
    const w = waterData.find((p) => p.zoneId === z.id);
    return {
      name: z.name,
      traffic: Math.round((t?.predictedCongestion || 0) * 100),
      energy: Math.round((e?.predictedDemand || 0)),
      water: Math.round((w?.predictedDemand || 0)),
    };
  });

  const isDark = document.documentElement.classList.contains('dark');
  const gridColor = isDark ? '#1e293b' : '#e2e8f0';
  const tickColor = isDark ? '#94a3b8' : '#64748b';

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">City Overview</h1>
          <p className="text-sm mirage-text-muted">Simulated smart city digital twin status — last updated {summary.simulationTime}</p>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 mirage-pulse" />
          <span className="text-xs font-medium mirage-text-muted">Simulation Active</span>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Monitored Zones" value={summary.totalZones} icon={<MapPin className="w-5 h-5" />} accentColor="#0ea5e9" />
        <StatCard label="Avg Congestion" value={Math.round(summary.traffic.avgCongestion * 100)} unit="%" icon={<Car className="w-5 h-5" />} accentColor="#f59e0b"
          subValue={`${summary.traffic.highRiskZones} high-risk zones`} />
        <StatCard label="Energy Gap" value={summary.energy.supplyGap.toFixed(1)} unit="MW" icon={<Zap className="w-5 h-5" />} accentColor="#ef4444"
          subValue={`${summary.energy.highRiskZones} high-risk zones`} />
        <StatCard label="Water Gap" value={summary.water.supplyGap.toFixed(1)} unit="ML" icon={<Droplets className="w-5 h-5" />} accentColor="#3b82f6"
          subValue={`${summary.water.highRiskZones} high-risk zones`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <SectionHeader title="Traffic Forecast" subtitle="12-hour congestion prediction" icon={<Car className="w-5 h-5" />} />
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={trafficChart}>
              <defs>
                <linearGradient id="trafficGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#f59e0b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis dataKey="hour" tick={{ fontSize: 10, fill: tickColor }} />
              <YAxis domain={[0, 1]} tick={{ fontSize: 10, fill: tickColor }} />
              <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
              <Area type="monotone" dataKey="congestion" stroke="#f59e0b" fill="url(#trafficGrad)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <SectionHeader title="Energy Forecast" subtitle="12-hour demand vs supply" icon={<Zap className="w-5 h-5" />} />
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={energyChart}>
              <defs>
                <linearGradient id="energyGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#ef4444" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#ef4444" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis dataKey="hour" tick={{ fontSize: 10, fill: tickColor }} />
              <YAxis tick={{ fontSize: 10, fill: tickColor }} />
              <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
              <Area type="monotone" dataKey="demand" stroke="#ef4444" fill="url(#energyGrad)" strokeWidth={2} />
              <Area type="monotone" dataKey="supply" stroke="#10b981" fill="none" strokeWidth={2} strokeDasharray="5 5" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <SectionHeader title="Water Forecast" subtitle="12-hour demand vs supply" icon={<Droplets className="w-5 h-5" />} />
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={waterChart}>
              <defs>
                <linearGradient id="waterGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis dataKey="hour" tick={{ fontSize: 10, fill: tickColor }} />
              <YAxis tick={{ fontSize: 10, fill: tickColor }} />
              <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
              <Area type="monotone" dataKey="demand" stroke="#3b82f6" fill="url(#waterGrad)" strokeWidth={2} />
              <Area type="monotone" dataKey="supply" stroke="#06b6d4" fill="none" strokeWidth={2} strokeDasharray="5 5" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <SectionHeader title="Zone Comparison" subtitle="Predicted metrics across all zones" icon={<Activity className="w-5 h-5" />} />
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={zoneBarData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis type="number" tick={{ fontSize: 10, fill: tickColor }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: tickColor }} width={80} />
              <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="traffic" fill="#f59e0b" name="Congestion %" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <SectionHeader title="Alert Summary" subtitle={`${summary.activeAlerts} active alerts, ${summary.criticalAlerts} critical`} icon={<ShieldAlert className="w-5 h-5" />} />
          <div className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-red-500/10 flex items-center justify-center">
                <AlertTriangle className="w-6 h-6 text-red-500" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Critical Alerts</span>
                  <span className="text-lg font-bold text-red-500">{summary.criticalAlerts}</span>
                </div>
                <ProgressBar value={summary.criticalAlerts} max={summary.totalZones * 3} color="#ef4444" />
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-orange-500/10 flex items-center justify-center">
                <ShieldAlert className="w-6 h-6 text-orange-500" />
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Total Active</span>
                  <span className="text-lg font-bold text-orange-500">{summary.activeAlerts}</span>
                </div>
                <ProgressBar value={summary.activeAlerts} max={summary.totalZones * 3} color="#f97316" />
              </div>
            </div>
            <div className="grid grid-cols-3 gap-2 pt-2">
              <div className="text-center p-2 rounded-lg bg-amber-500/10">
                <Car className="w-4 h-4 mx-auto text-amber-500" />
                <p className="text-xs mt-1 mirage-text-muted">Traffic</p>
                <p className="text-sm font-bold">{summary.traffic.highRiskZones}</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-red-500/10">
                <Zap className="w-4 h-4 mx-auto text-red-500" />
                <p className="text-xs mt-1 mirage-text-muted">Energy</p>
                <p className="text-sm font-bold">{summary.energy.highRiskZones}</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-blue-500/10">
                <Droplets className="w-4 h-4 mx-auto text-blue-500" />
                <p className="text-xs mt-1 mirage-text-muted">Water</p>
                <p className="text-sm font-bold">{summary.water.highRiskZones}</p>
              </div>
            </div>
          </div>
        </Card>
      </div>

      <Card>
        <SectionHeader title="City Zones" subtitle="All monitored zones with current status" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
          {ZONES.map((zone) => {
            const t = trafficData.find((p) => p.zoneId === zone.id);
            return (
              <div key={zone.id} className="p-3 rounded-lg border border-slate-200 dark:border-slate-700">
                <div className="flex items-center gap-2 mb-2">
                  <span className="w-3 h-3 rounded-full" style={{ backgroundColor: ZONE_TYPE_COLORS[zone.type] }} />
                  <span className="text-sm font-semibold">{zone.name}</span>
                </div>
                <p className="text-xs mirage-text-muted mb-2">{zoneTypeLabel(zone.type)} · Pop: {zone.population.toLocaleString()}</p>
                <div className="flex items-center justify-between text-xs">
                  <span className="mirage-text-muted">Congestion:</span>
                  <RiskBadge level={t?.riskLevel || 'low'} />
                </div>
              </div>
            );
          })}
        </div>
      </Card>

      <p className="text-xs mirage-text-muted text-center pb-4">
        All data shown is synthetically generated for simulation purposes. This does not represent real city sensor readings.
      </p>
    </div>
  );
}
