import { useState } from 'react';
import { Card, SectionHeader, Button, Slider, Toggle } from '@/components/ui';
import { DEFAULT_SCENARIO } from '@/lib/simulationEngine';
import { DEFAULT_THRESHOLDS } from '@/lib/riskEngine';
import { saveSimulation } from '@/lib/supabase';
import { runScenario } from '@/lib/simulationEngine';
import { detectRisks } from '@/lib/riskEngine';
import { downloadFullReport } from '@/lib/export';
import type { ScenarioParams } from '@/lib/types';
import { Settings, Save, Download, Info, SlidersHorizontal } from 'lucide-react';

export function SettingsPage() {
  const [params, setParams] = useState<ScenarioParams>({ ...DEFAULT_SCENARIO });
  const [simName, setSimName] = useState('');
  const [simNotes, setSimNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');

  async function handleSave() {
    if (!simName.trim()) {
      setSaveStatus('error');
      return;
    }
    setSaving(true);
    setSaveStatus('idle');
    const result = runScenario(params);
    const alerts = detectRisks(params);
    const saved = await saveSimulation({
      name: simName,
      module: 'combined',
      scenario_params: params as unknown as Record<string, unknown>,
      baseline_results: runScenario(DEFAULT_SCENARIO) as unknown as Record<string, unknown>,
      modified_results: result as unknown as Record<string, unknown>,
      risk_alerts: alerts as unknown as Record<string, unknown>[],
      optimization_result: null,
      notes: simNotes,
    });
    setSaving(false);
    if (saved) {
      setSaveStatus('success');
      setSimName('');
      setSimNotes('');
    } else {
      setSaveStatus('error');
    }
  }

  function handleExport() {
    const result = runScenario(params);
    const alerts = detectRisks(params);
    downloadFullReport(params, result, alerts, null, 'Random Forest (15 trees)');
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Settings</h1>
        <p className="text-sm mirage-text-muted">Configure simulation defaults, save scenarios, and export reports</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <SectionHeader title="Default Scenario" subtitle="Set parameters for the default simulation" icon={<SlidersHorizontal className="w-5 h-5" />} />
          <div className="space-y-4">
            <Slider label="Traffic Volume" value={params.trafficMultiplier} min={0.5} max={2} step={0.05} onChange={(v) => setParams({ ...params, trafficMultiplier: v })} format={(v) => `${Math.round(v * 100)}%`} />
            <Slider label="Energy Supply Change" value={params.energySupplyChange} min={-30} max={20} step={1} onChange={(v) => setParams({ ...params, energySupplyChange: v })} suffix="%" />
            <Slider label="Water Demand Change" value={params.waterDemandChange} min={-30} max={50} step={1} onChange={(v) => setParams({ ...params, waterDemandChange: v })} suffix="%" />
            <Slider label="Temperature Offset" value={params.temperatureOffset} min={-10} max={15} step={1} onChange={(v) => setParams({ ...params, temperatureOffset: v })} suffix="°C" />
            <Slider label="Load Shedding" value={params.loadShedding} min={0} max={30} step={1} onChange={(v) => setParams({ ...params, loadShedding: v })} suffix="%" />
            <div>
              <span className="text-sm font-medium mb-2 block">Weather Scenario</span>
              <select
                value={params.weatherScenario}
                onChange={(e) => setParams({ ...params, weatherScenario: e.target.value as ScenarioParams['weatherScenario'] })}
                className="w-full px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700"
              >
                <option value="clear">Clear</option>
                <option value="cloudy">Cloudy</option>
                <option value="rain">Rain</option>
                <option value="storm">Storm</option>
                <option value="heatwave">Heatwave</option>
              </select>
            </div>
            <Toggle checked={params.signalOptimization} onChange={(v) => setParams({ ...params, signalOptimization: v })} label="Traffic Signal Optimization" />
            <Toggle checked={params.waterConservation} onChange={(v) => setParams({ ...params, waterConservation: v })} label="Water Conservation Measures" />
          </div>
        </Card>

        <div className="space-y-4">
          <Card>
            <SectionHeader title="Save Simulation" subtitle="Persist current scenario to database history" icon={<Save className="w-5 h-5" />} />
            <div className="space-y-3">
              <div>
                <span className="text-sm font-medium mb-1 block">Simulation Name</span>
                <input
                  type="text"
                  value={simName}
                  onChange={(e) => setSimName(e.target.value)}
                  placeholder="e.g. Heatwave response test"
                  className="w-full px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700"
                />
              </div>
              <div>
                <span className="text-sm font-medium mb-1 block">Notes (optional)</span>
                <textarea
                  value={simNotes}
                  onChange={(e) => setSimNotes(e.target.value)}
                  placeholder="Add observations or context..."
                  rows={3}
                  className="w-full px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700 resize-none"
                />
              </div>
              <Button onClick={handleSave} disabled={saving || !simName.trim()} className="w-full">
                <span className="flex items-center justify-center gap-2">
                  {saving ? 'Saving...' : 'Save to History'}
                  <Save className="w-4 h-4" />
                </span>
              </Button>
              {saveStatus === 'success' && (
                <p className="text-sm text-emerald-500">Simulation saved successfully. View it in Simulation History.</p>
              )}
              {saveStatus === 'error' && (
                <p className="text-sm text-red-500">Failed to save. Please enter a name and try again.</p>
              )}
            </div>
          </Card>

          <Card>
            <SectionHeader title="Export Report" subtitle="Download current scenario as CSV" icon={<Download className="w-5 h-5" />} />
            <Button variant="secondary" onClick={handleExport} className="w-full">
              <span className="flex items-center justify-center gap-2"><Download className="w-4 h-4" /> Export Full Report (CSV)</span>
            </Button>
          </Card>

          <Card>
            <SectionHeader title="Risk Thresholds" subtitle="Currently configured risk classification thresholds" icon={<Info className="w-5 h-5" />} />
            <div className="space-y-2 text-xs">
              <div className="flex justify-between p-2 rounded-lg bg-amber-500/5">
                <span>Traffic Medium/High/Critical</span>
                <span className="font-medium">{DEFAULT_THRESHOLDS.traffic.medium} / {DEFAULT_THRESHOLDS.traffic.high} / {DEFAULT_THRESHOLDS.traffic.critical}</span>
              </div>
              <div className="flex justify-between p-2 rounded-lg bg-red-500/5">
                <span>Energy Medium/High/Critical</span>
                <span className="font-medium">{DEFAULT_THRESHOLDS.energy.medium} / {DEFAULT_THRESHOLDS.energy.high} / {DEFAULT_THRESHOLDS.energy.critical}</span>
              </div>
              <div className="flex justify-between p-2 rounded-lg bg-blue-500/5">
                <span>Water Medium/High/Critical</span>
                <span className="font-medium">{DEFAULT_THRESHOLDS.water.medium} / {DEFAULT_THRESHOLDS.water.high} / {DEFAULT_THRESHOLDS.water.critical}</span>
              </div>
            </div>
          </Card>

          <Card>
            <SectionHeader title="About" icon={<Settings className="w-5 h-5" />} />
            <div className="text-sm space-y-2 mirage-text-muted">
              <p><span className="font-semibold text-slate-700 dark:text-slate-200">PROJECT MIRAGE</span> — Predictive Digital Twin and Intelligent Risk Simulation Platform.</p>
              <p>Smart City Digital Twin with traffic, energy, and water prediction modules powered by a TypeScript Random Forest implementation trained on synthetic data.</p>
              <p>All data is simulated. Strong performance on synthetic data does not establish real-world predictive accuracy.</p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
