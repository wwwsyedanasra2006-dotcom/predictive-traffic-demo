import { useEffect, useState } from 'react';
import { Card, SectionHeader, Button, EmptyState, RiskBadge, StatCard } from '@/components/ui';
import { listSimulations, deleteSimulation, type SimulationHistoryRecord } from '@/lib/supabase';
import { downloadFullReport } from '@/lib/export';
import { runScenario } from '@/lib/simulationEngine';
import type { ScenarioResult, RiskAlert, ScenarioParams, OptimizationResult } from '@/lib/types';
import { History, Trash2, Download, RefreshCw, Search, FileText, GitCompare, X } from 'lucide-react';

export function SimulationHistoryPage() {
  const [simulations, setSimulations] = useState<SimulationHistoryRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<SimulationHistoryRecord | null>(null);
  const [search, setSearch] = useState('');
  const [compareIds, setCompareIds] = useState<string[]>([]);

  async function load() {
    setLoading(true);
    setError(null);
    try {
      const data = await listSimulations();
      setSimulations(data);
    } catch {
      setError('Failed to load simulations. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function handleDelete(id: string) {
    const ok = await deleteSimulation(id);
    if (ok) {
      setSimulations((prev) => prev.filter((s) => s.id !== id));
      if (selected?.id === id) setSelected(null);
      setCompareIds((prev) => prev.filter((cid) => cid !== id));
    }
  }

  function handleExport(sim: SimulationHistoryRecord) {
    const params = sim.scenario_params as unknown as ScenarioParams;
    const result = sim.modified_results as unknown as ScenarioResult;
    const alerts = (sim.risk_alerts || []) as unknown as RiskAlert[];
    const opt = sim.optimization_result as unknown as OptimizationResult | null;
    downloadFullReport(params, result, alerts, opt, 'Random Forest (15 trees)');
  }

  function toggleCompare(id: string) {
    setCompareIds((prev) => {
      if (prev.includes(id)) return prev.filter((cid) => cid !== id);
      if (prev.length >= 2) return [prev[1], id];
      return [...prev, id];
    });
  }

  const filtered = simulations.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.module.toLowerCase().includes(search.toLowerCase())
  );

  const compareSims = compareIds
    .map((id) => simulations.find((s) => s.id === id))
    .filter((s): s is SimulationHistoryRecord => s !== undefined);

  function extractSummary(sim: SimulationHistoryRecord) {
    const result = sim.modified_results as unknown as ScenarioResult;
    const params = sim.scenario_params as unknown as ScenarioParams;
    const alerts = (sim.risk_alerts || []) as unknown as RiskAlert[];
    return {
      name: sim.name,
      date: new Date(sim.created_at).toLocaleString(),
      trafficMultiplier: params.trafficMultiplier,
      energySupplyChange: params.energySupplyChange,
      waterDemandChange: params.waterDemandChange,
      weather: params.weatherScenario,
      tempOffset: params.temperatureOffset,
      signalOpt: params.signalOptimization,
      waterCons: params.waterConservation,
      loadShedding: params.loadShedding,
      overallRiskReduction: result.summary.overallRiskReduction,
      trafficImprovement: result.summary.trafficImprovement,
      energySavings: result.summary.energySavings,
      waterSavings: result.summary.waterSavings,
      alertCount: alerts.length,
      criticalCount: alerts.filter((a) => a.riskLevel === 'critical').length,
    };
  }

  const compareData = compareSims.map(extractSummary);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Simulation History</h1>
          <p className="text-sm mirage-text-muted">Saved simulation runs stored in persistent database — select two to compare</p>
        </div>
        <Button variant="secondary" size="sm" onClick={load} disabled={loading}>
          <span className="flex items-center gap-1.5"><RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh</span>
        </Button>
      </div>

      {error && (
        <Card className="border-red-500/30">
          <p className="text-sm text-red-500">{error}</p>
        </Card>
      )}

      <Card>
        <div className="flex items-center justify-between gap-3 mb-4">
          <div className="flex items-center gap-3 flex-1">
            <Search className="w-4 h-4 mirage-text-muted" />
            <input
              type="text"
              placeholder="Search by name or module..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="flex-1 px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700"
            />
          </div>
          {compareIds.length > 0 && (
            <Button variant="ghost" size="sm" onClick={() => setCompareIds([])}>
              <span className="flex items-center gap-1.5"><X className="w-3.5 h-3.5" /> Clear Compare</span>
            </Button>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <RefreshCw className="w-6 h-6 text-sky-500 animate-spin" />
          </div>
        ) : filtered.length === 0 ? (
          <EmptyState message="No saved simulations yet. Save a scenario from Settings or the What-If Simulator to see it here." icon={<History className="w-10 h-10" />} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="text-left py-2 px-3 font-semibold w-8"></th>
                  <th className="text-left py-2 px-3 font-semibold">Name</th>
                  <th className="text-left py-2 px-3 font-semibold">Module</th>
                  <th className="text-left py-2 px-3 font-semibold">Date</th>
                  <th className="text-left py-2 px-3 font-semibold">Alerts</th>
                  <th className="text-right py-2 px-3 font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((sim) => {
                  const alerts = (sim.risk_alerts || []) as unknown as RiskAlert[];
                  const criticalCount = alerts.filter((a) => a.riskLevel === 'critical').length;
                  const isCompareSelected = compareIds.includes(sim.id);
                  return (
                    <tr
                      key={sim.id}
                      className={`border-b border-slate-100 dark:border-slate-800 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/30 ${selected?.id === sim.id ? 'bg-sky-500/5' : ''} ${isCompareSelected ? 'bg-emerald-500/5' : ''}`}
                      onClick={() => setSelected(sim)}
                    >
                      <td className="py-2 px-3" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => toggleCompare(sim.id)}
                          className={`p-1.5 rounded-lg transition-colors ${isCompareSelected ? 'text-emerald-500 bg-emerald-500/10' : 'mirage-text-muted hover:bg-slate-200 dark:hover:bg-slate-700'}`}
                          title="Select for comparison"
                        >
                          <GitCompare className="w-3.5 h-3.5" />
                        </button>
                      </td>
                      <td className="py-2 px-3 font-medium">{sim.name}</td>
                      <td className="py-2 px-3 capitalize">{sim.module}</td>
                      <td className="py-2 px-3 mirage-text-muted text-xs">{new Date(sim.created_at).toLocaleString()}</td>
                      <td className="py-2 px-3">
                        <span className="text-xs">{alerts.length} alerts{criticalCount > 0 && <span className="text-red-500 font-semibold"> ({criticalCount} critical)</span>}</span>
                      </td>
                      <td className="text-right py-2 px-3" onClick={(e) => e.stopPropagation()}>
                        <div className="flex justify-end gap-1">
                          <button onClick={() => handleExport(sim)} className="p-1.5 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700" title="Export CSV">
                            <Download className="w-3.5 h-3.5" />
                          </button>
                          <button onClick={() => handleDelete(sim.id)} className="p-1.5 rounded-lg hover:bg-red-500/10 text-red-500" title="Delete">
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {compareData.length > 0 && (
        <Card>
          <SectionHeader title="Scenario Comparison" subtitle={`${compareData.length} simulation${compareData.length > 1 ? 's' : ''} selected — select 2 to compare side by side`} icon={<GitCompare className="w-5 h-5" />} />
          {compareData.length === 2 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-700">
                    <th className="text-left py-2 px-3 font-semibold">Metric</th>
                    <th className="text-right py-2 px-3 font-semibold">{compareData[0].name}</th>
                    <th className="text-right py-2 px-3 font-semibold">{compareData[1].name}</th>
                    <th className="text-right py-2 px-3 font-semibold">Difference</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 mirage-text-muted">Date</td>
                    <td className="text-right py-2 px-3 text-xs">{compareData[0].date}</td>
                    <td className="text-right py-2 px-3 text-xs">{compareData[1].date}</td>
                    <td className="text-right py-2 px-3 text-xs mirage-text-muted">—</td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 mirage-text-muted">Traffic Volume</td>
                    <td className="text-right py-2 px-3">{compareData[0].trafficMultiplier}x</td>
                    <td className="text-right py-2 px-3">{compareData[1].trafficMultiplier}x</td>
                    <td className="text-right py-2 px-3 font-semibold">{(compareData[1].trafficMultiplier - compareData[0].trafficMultiplier).toFixed(2)}x</td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 mirage-text-muted">Energy Supply Change</td>
                    <td className="text-right py-2 px-3">{compareData[0].energySupplyChange}%</td>
                    <td className="text-right py-2 px-3">{compareData[1].energySupplyChange}%</td>
                    <td className="text-right py-2 px-3 font-semibold">{compareData[1].energySupplyChange - compareData[0].energySupplyChange}%</td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 mirage-text-muted">Water Demand Change</td>
                    <td className="text-right py-2 px-3">{compareData[0].waterDemandChange}%</td>
                    <td className="text-right py-2 px-3">{compareData[1].waterDemandChange}%</td>
                    <td className="text-right py-2 px-3 font-semibold">{compareData[1].waterDemandChange - compareData[0].waterDemandChange}%</td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 mirage-text-muted">Weather</td>
                    <td className="text-right py-2 px-3 capitalize">{compareData[0].weather}</td>
                    <td className="text-right py-2 px-3 capitalize">{compareData[1].weather}</td>
                    <td className="text-right py-2 px-3 text-xs mirage-text-muted">{compareData[0].weather === compareData[1].weather ? 'Same' : 'Different'}</td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 mirage-text-muted">Temp Offset</td>
                    <td className="text-right py-2 px-3">{compareData[0].tempOffset}°C</td>
                    <td className="text-right py-2 px-3">{compareData[1].tempOffset}°C</td>
                    <td className="text-right py-2 px-3 font-semibold">{compareData[1].tempOffset - compareData[0].tempOffset}°C</td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 font-semibold">Overall Risk Reduction</td>
                    <td className="text-right py-2 px-3 font-semibold text-sky-500">{compareData[0].overallRiskReduction}%</td>
                    <td className="text-right py-2 px-3 font-semibold text-sky-500">{compareData[1].overallRiskReduction}%</td>
                    <td className="text-right py-2 px-3 font-semibold" style={{ color: compareData[1].overallRiskReduction > compareData[0].overallRiskReduction ? '#10b981' : '#ef4444' }}>
                      {(compareData[1].overallRiskReduction - compareData[0].overallRiskReduction).toFixed(2)}%
                    </td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 font-semibold">Traffic Improvement</td>
                    <td className="text-right py-2 px-3">{compareData[0].trafficImprovement}</td>
                    <td className="text-right py-2 px-3">{compareData[1].trafficImprovement}</td>
                    <td className="text-right py-2 px-3 font-semibold">{(compareData[1].trafficImprovement - compareData[0].trafficImprovement).toFixed(3)}</td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 font-semibold">Energy Savings (MW)</td>
                    <td className="text-right py-2 px-3">{compareData[0].energySavings}</td>
                    <td className="text-right py-2 px-3">{compareData[1].energySavings}</td>
                    <td className="text-right py-2 px-3 font-semibold">{(compareData[1].energySavings - compareData[0].energySavings).toFixed(2)}</td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 font-semibold">Water Savings (ML)</td>
                    <td className="text-right py-2 px-3">{compareData[0].waterSavings}</td>
                    <td className="text-right py-2 px-3">{compareData[1].waterSavings}</td>
                    <td className="text-right py-2 px-3 font-semibold">{(compareData[1].waterSavings - compareData[0].waterSavings).toFixed(2)}</td>
                  </tr>
                  <tr className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 font-semibold">Total Alerts</td>
                    <td className="text-right py-2 px-3">{compareData[0].alertCount}</td>
                    <td className="text-right py-2 px-3">{compareData[1].alertCount}</td>
                    <td className="text-right py-2 px-3 font-semibold" style={{ color: compareData[1].alertCount < compareData[0].alertCount ? '#10b981' : '#ef4444' }}>
                      {compareData[1].alertCount - compareData[0].alertCount}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2 px-3 font-semibold">Critical Alerts</td>
                    <td className="text-right py-2 px-3 text-red-500">{compareData[0].criticalCount}</td>
                    <td className="text-right py-2 px-3 text-red-500">{compareData[1].criticalCount}</td>
                    <td className="text-right py-2 px-3 font-semibold" style={{ color: compareData[1].criticalCount < compareData[0].criticalCount ? '#10b981' : '#ef4444' }}>
                      {compareData[1].criticalCount - compareData[0].criticalCount}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-sm mirage-text-muted">Select one more simulation to compare. Currently {compareData.length} selected.</p>
          )}
        </Card>
      )}

      {selected && (
        <Card>
          <SectionHeader title={`Detail: ${selected.name}`} subtitle={`Saved ${new Date(selected.created_at).toLocaleString()}`} icon={<FileText className="w-5 h-5" />} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
              <p className="text-xs font-semibold mb-2">Scenario Parameters</p>
              <div className="p-3 rounded-lg bg-slate-100 dark:bg-slate-800/50 space-y-1 text-xs">
                <div className="flex justify-between"><span className="mirage-text-muted">Traffic Volume:</span><span className="font-medium">{(selected.scenario_params as unknown as ScenarioParams).trafficMultiplier}x</span></div>
                <div className="flex justify-between"><span className="mirage-text-muted">Energy Supply:</span><span className="font-medium">{(selected.scenario_params as unknown as ScenarioParams).energySupplyChange}%</span></div>
                <div className="flex justify-between"><span className="mirage-text-muted">Water Demand:</span><span className="font-medium">{(selected.scenario_params as unknown as ScenarioParams).waterDemandChange}%</span></div>
                <div className="flex justify-between"><span className="mirage-text-muted">Weather:</span><span className="font-medium capitalize">{(selected.scenario_params as unknown as ScenarioParams).weatherScenario}</span></div>
                <div className="flex justify-between"><span className="mirage-text-muted">Temp Offset:</span><span className="font-medium">{(selected.scenario_params as unknown as ScenarioParams).temperatureOffset}°C</span></div>
                <div className="flex justify-between"><span className="mirage-text-muted">Signal Opt:</span><span className="font-medium">{(selected.scenario_params as unknown as ScenarioParams).signalOptimization ? 'Yes' : 'No'}</span></div>
                <div className="flex justify-between"><span className="mirage-text-muted">Water Cons:</span><span className="font-medium">{(selected.scenario_params as unknown as ScenarioParams).waterConservation ? 'Yes' : 'No'}</span></div>
              </div>
            </div>
            <div>
              <p className="text-xs font-semibold mb-2">Risk Alerts ({((selected.risk_alerts || []) as unknown as RiskAlert[]).length})</p>
              <div className="space-y-2 max-h-48 overflow-y-auto mirage-scrollbar">
                {((selected.risk_alerts || []) as unknown as RiskAlert[]).slice(0, 10).map((alert) => (
                  <div key={alert.id} className="flex items-center justify-between p-2 rounded-lg bg-slate-100 dark:bg-slate-800/50 text-xs">
                    <span className="font-medium">{alert.zoneName}</span>
                    <span className="mirage-text-muted capitalize">{alert.module}</span>
                    <RiskBadge level={alert.riskLevel} />
                  </div>
                ))}
              </div>
            </div>
          </div>
          {(() => {
            const result = selected.modified_results as unknown as ScenarioResult;
            return (
              <div className="mt-4 grid grid-cols-2 lg:grid-cols-4 gap-3">
                <StatCard label="Risk Reduction" value={`${result.summary.overallRiskReduction}%`} accentColor="#0ea5e9" />
                <StatCard label="Traffic Improvement" value={result.summary.trafficImprovement.toFixed(3)} accentColor="#f59e0b" />
                <StatCard label="Energy Savings" value={`${result.summary.energySavings} MW`} accentColor="#ef4444" />
                <StatCard label="Water Savings" value={`${result.summary.waterSavings} ML`} accentColor="#3b82f6" />
              </div>
            );
          })()}
          {selected.notes && (
            <div className="mt-4 p-3 rounded-lg bg-sky-500/5 border border-sky-500/20">
              <p className="text-xs font-semibold mb-1">Notes</p>
              <p className="text-sm">{selected.notes}</p>
            </div>
          )}
        </Card>
      )}

      <p className="text-xs mirage-text-muted text-center">
        Simulations are persisted in a Supabase database and survive browser refreshes. Use the compare icon to select two runs and see side-by-side differences.
      </p>
    </div>
  );
}
