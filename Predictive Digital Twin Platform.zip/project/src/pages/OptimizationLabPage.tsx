import { useMemo, useState } from 'react';
import { Card, StatCard, SectionHeader, Button, Slider } from '@/components/ui';
import { optimizeEnergyAllocation, optimizeWaterAllocation } from '@/lib/optimizationEngine';
import { predictEnergy, predictWater } from '@/lib/predictions';
import { DEFAULT_SCENARIO } from '@/lib/simulationEngine';
import { exportOptimizationCSV, downloadCSV } from '@/lib/export';
import type { ScenarioParams } from '@/lib/types';
import { FlaskConical, Zap, Droplets, Download, TrendingDown, CheckCircle, AlertCircle } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';

export function OptimizationLabPage() {
  const [params, setParams] = useState<ScenarioParams>({ ...DEFAULT_SCENARIO });
  const [module, setModule] = useState<'energy' | 'water'>('energy');
  const [supplyMultiplier, setSupplyMultiplier] = useState(0.8);

  const energyPreds = useMemo(() => predictEnergy(params, 6), [params]);
  const waterPreds = useMemo(() => predictWater(params, 6), [params]);

  const isDark = document.documentElement.classList.contains('dark');
  const gridColor = isDark ? '#1e293b' : '#e2e8f0';
  const tickColor = isDark ? '#94a3b8' : '#64748b';
  const tooltipStyle = { background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 };

  const optimization = useMemo(() => {
    if (module === 'energy') {
      const demands = energyPreds.map((p) => ({ zoneId: p.zoneId, demand: p.predictedDemand }));
      const totalSupply = energyPreds.reduce((s, p) => s + p.supply, 0) * supplyMultiplier;
      return optimizeEnergyAllocation(demands, totalSupply);
    } else {
      const demands = waterPreds.map((p) => ({ zoneId: p.zoneId, demand: p.predictedDemand }));
      const totalSupply = waterPreds.reduce((s, p) => s + p.supply, 0) * supplyMultiplier;
      return optimizeWaterAllocation(demands, totalSupply);
    }
  }, [module, energyPreds, waterPreds, supplyMultiplier]);

  const chartData = optimization.allocation.map((a) => ({
    name: a.zoneName,
    demand: Math.round(a.demand * 10) / 10,
    allocated: Math.round(a.allocated * 10) / 10,
    unmet: Math.round(a.unmet * 10) / 10,
  }));

  const unit = module === 'energy' ? 'MW' : 'ML';
  const accentColor = module === 'energy' ? '#ef4444' : '#3b82f6';

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Optimization Lab</h1>
          <p className="text-sm mirage-text-muted">Constrained greedy resource allocation under supply and priority constraints</p>
        </div>
        <Button variant="secondary" size="sm" onClick={() => downloadCSV(exportOptimizationCSV(optimization), `mirage_optimization_${module}_${Date.now()}.csv`)}>
          <span className="flex items-center gap-1.5"><Download className="w-3.5 h-3.5" /> Export</span>
        </Button>
      </div>

      <Card>
        <SectionHeader title="Optimization Configuration" icon={<FlaskConical className="w-5 h-5" />} />
        <div className="flex flex-wrap gap-6">
          <div className="flex gap-2">
            <button
              onClick={() => setModule('energy')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${module === 'energy' ? 'bg-red-500 text-white' : 'mirage-surface'}`}
            >
              <Zap className="w-4 h-4" /> Energy
            </button>
            <button
              onClick={() => setModule('water')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all flex items-center gap-2 ${module === 'water' ? 'bg-blue-500 text-white' : 'mirage-surface'}`}
            >
              <Droplets className="w-4 h-4" /> Water
            </button>
          </div>
          <div className="flex-1 min-w-[200px]">
            <Slider
              label="Available Supply (fraction of total capacity)"
              value={supplyMultiplier}
              min={0.3}
              max={1.0}
              step={0.05}
              onChange={setSupplyMultiplier}
              format={(v) => `${Math.round(v * 100)}%`}
            />
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Total Resource" value={optimization.totalResource.toFixed(1)} unit={unit} icon={module === 'energy' ? <Zap className="w-5 h-5" /> : <Droplets className="w-5 h-5" />} accentColor={accentColor} />
        <StatCard label="Total Demand" value={optimization.totalDemand.toFixed(1)} unit={unit} icon={<TrendingDown className="w-5 h-5" />} accentColor="#f59e0b" />
        <StatCard label="Total Unmet" value={optimization.totalUnmet.toFixed(1)} unit={unit} icon={<AlertCircle className="w-5 h-5" />} accentColor="#ef4444" />
        <StatCard label="Fulfillment Rate" value={Math.round(optimization.objectiveValue * 100)} unit="%" icon={<CheckCircle className="w-5 h-5" />} accentColor="#10b981" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <SectionHeader title="Allocation by Zone" subtitle={`Demand vs allocated (${unit})`} />
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis dataKey="name" tick={{ fontSize: 9, fill: tickColor }} angle={-30} textAnchor="end" height={60} />
              <YAxis tick={{ fontSize: 10, fill: tickColor }} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              <Bar dataKey="demand" fill="#f59e0b" name={`Demand (${unit})`} radius={[4, 4, 0, 0]} />
              <Bar dataKey="allocated" fill="#10b981" name={`Allocated (${unit})`} radius={[4, 4, 0, 0]} />
              <Bar dataKey="unmet" fill="#ef4444" name={`Unmet (${unit})`} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <SectionHeader title="Optimization Explanation" subtitle="How the algorithm decided the allocation" icon={<FlaskConical className="w-5 h-5" />} />
          <div className="p-4 rounded-lg bg-sky-500/5 border border-sky-500/20">
            <p className="text-sm">{optimization.explanation}</p>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-3">
            <div className="text-center p-3 rounded-lg bg-red-500/10">
              <p className="text-xs mirage-text-muted">Baseline Unmet</p>
              <p className="text-xl font-bold text-red-500">{optimization.baselineUnmet.toFixed(1)}</p>
              <p className="text-xs mirage-text-muted">{unit}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-amber-500/10">
              <p className="text-xs mirage-text-muted">Optimized Unmet</p>
              <p className="text-xl font-bold text-amber-500">{optimization.optimizedUnmet.toFixed(1)}</p>
              <p className="text-xs mirage-text-muted">{unit}</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-emerald-500/10">
              <p className="text-xs mirage-text-muted">Improvement</p>
              <p className="text-xl font-bold text-emerald-500">{optimization.improvement.toFixed(1)}</p>
              <p className="text-xs mirage-text-muted">{unit}</p>
            </div>
          </div>
          <div className="mt-4 p-3 rounded-lg bg-slate-100 dark:bg-slate-800/50">
            <p className="text-xs font-semibold mb-1">Objective Function</p>
            <p className="text-xs mirage-text-muted">Maximize fulfilled demand weighted by zone priority (residential: 3, commercial/transport: 2, industrial: 1), subject to total supply constraint.</p>
          </div>
        </Card>
      </div>

      <Card>
        <SectionHeader title="Detailed Allocation Table" />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700">
                <th className="text-left py-2 px-3 font-semibold">Zone</th>
                <th className="text-right py-2 px-3 font-semibold">Priority</th>
                <th className="text-right py-2 px-3 font-semibold">Demand ({unit})</th>
                <th className="text-right py-2 px-3 font-semibold">Allocated ({unit})</th>
                <th className="text-right py-2 px-3 font-semibold">Unmet ({unit})</th>
                <th className="text-right py-2 px-3 font-semibold">Fulfilled %</th>
              </tr>
            </thead>
            <tbody>
              {optimization.allocation.map((a) => {
                const pct = a.demand > 0 ? (a.allocated / a.demand) * 100 : 100;
                return (
                  <tr key={a.zoneId} className="border-b border-slate-100 dark:border-slate-800">
                    <td className="py-2 px-3 font-medium">{a.zoneName}</td>
                    <td className="text-right py-2 px-3">{a.priority}</td>
                    <td className="text-right py-2 px-3">{a.demand.toFixed(2)}</td>
                    <td className="text-right py-2 px-3 font-semibold text-emerald-500">{a.allocated.toFixed(2)}</td>
                    <td className="text-right py-2 px-3" style={{ color: a.unmet > 0 ? '#ef4444' : '#10b981' }}>{a.unmet.toFixed(2)}</td>
                    <td className="text-right py-2 px-3">
                      <span className={pct >= 100 ? 'text-emerald-500' : pct >= 50 ? 'text-amber-500' : 'text-red-500'}>
                        {pct.toFixed(0)}%
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      <p className="text-xs mirage-text-muted text-center">
        The optimizer uses a constrained greedy algorithm: zones are served in priority order, each receiving up to 1.5× the per-zone share, then surplus redistributes to zones with unmet demand. Demand values come from Random Forest model predictions on synthetic data. Total allocated never exceeds available supply — this is a deterministic calculation, not a prediction.
      </p>
    </div>
  );
}
