import { useMemo, useState } from 'react';
import { Card, StatCard, SectionHeader, RiskBadge, Button, EmptyState, Slider, Toggle } from '@/components/ui';
import { detectRisks, DEFAULT_THRESHOLDS } from '@/lib/riskEngine';
import { DEFAULT_SCENARIO } from '@/lib/simulationEngine';
import { exportAlertsCSV, downloadCSV } from '@/lib/export';
import type { ScenarioParams, RiskLevel } from '@/lib/types';
import { ShieldAlert, AlertTriangle, Download, Car, Zap, Droplets, Filter, SlidersHorizontal, RotateCcw } from 'lucide-react';

const MODULE_ICONS: Record<string, typeof Car> = {
  traffic: Car,
  energy: Zap,
  water: Droplets,
};

const MODULE_COLORS: Record<string, string> = {
  traffic: '#f59e0b',
  energy: '#ef4444',
  water: '#3b82f6',
};

export function RiskCenterPage() {
  const [params, setParams] = useState<ScenarioParams>({ ...DEFAULT_SCENARIO });
  const [filterModule, setFilterModule] = useState<string>('all');
  const [filterLevel, setFilterLevel] = useState<string>('all');

  const alerts = useMemo(() => detectRisks(params, DEFAULT_THRESHOLDS, 12), [params]);

  const filtered = alerts.filter((a) => {
    if (filterModule !== 'all' && a.module !== filterModule) return false;
    if (filterLevel !== 'all' && a.riskLevel !== filterLevel) return false;
    return true;
  });

  const counts: Record<RiskLevel, number> = { low: 0, medium: 0, high: 0, critical: 0 };
  alerts.forEach((a) => counts[a.riskLevel]++);

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">Risk Center</h1>
          <p className="text-sm mirage-text-muted">Early warning system with configurable thresholds and explainable risk factors</p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" onClick={() => setParams({ ...DEFAULT_SCENARIO })}>
            <span className="flex items-center gap-1.5"><RotateCcw className="w-3.5 h-3.5" /> Reset</span>
          </Button>
          <Button variant="secondary" size="sm" onClick={() => downloadCSV(exportAlertsCSV(alerts), `mirage_alerts_${Date.now()}.csv`)}>
            <span className="flex items-center gap-1.5"><Download className="w-3.5 h-3.5" /> Export Alerts</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Critical" value={counts.critical} icon={<AlertTriangle className="w-5 h-5" />} accentColor="#ef4444" />
        <StatCard label="High" value={counts.high} icon={<ShieldAlert className="w-5 h-5" />} accentColor="#f97316" />
        <StatCard label="Medium" value={counts.medium} icon={<ShieldAlert className="w-5 h-5" />} accentColor="#f59e0b" />
        <StatCard label="Total Alerts" value={alerts.length} icon={<ShieldAlert className="w-5 h-5" />} accentColor="#0ea5e9" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <SectionHeader title="Scenario Controls" subtitle="Adjust conditions to see risk levels change" icon={<SlidersHorizontal className="w-5 h-5" />} />
          <div className="space-y-4">
            <Slider label="Traffic Volume" value={params.trafficMultiplier} min={0.5} max={2} step={0.05} onChange={(v) => setParams({ ...params, trafficMultiplier: v })} format={(v) => `${Math.round(v * 100)}%`} />
            <Slider label="Energy Supply Change" value={params.energySupplyChange} min={-30} max={20} step={1} onChange={(v) => setParams({ ...params, energySupplyChange: v })} suffix="%" />
            <Slider label="Water Demand Change" value={params.waterDemandChange} min={-30} max={50} step={1} onChange={(v) => setParams({ ...params, waterDemandChange: v })} suffix="%" />
            <Slider label="Temperature Offset" value={params.temperatureOffset} min={-10} max={15} step={1} onChange={(v) => setParams({ ...params, temperatureOffset: v })} suffix="°C" />
            <Slider label="Load Shedding" value={params.loadShedding} min={0} max={30} step={1} onChange={(v) => setParams({ ...params, loadShedding: v })} suffix="%" />
            <div>
              <span className="text-sm font-medium mb-2 block">Weather Scenario</span>
              <select
                value={params.weatherScenario}
                onChange={(e) => setParams({ ...params, weatherScenario: e.target.value as ScenarioParams['weatherScenario'] })}
                className="w-full px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700"
              >
                <option value="clear">Clear</option>
                <option value="cloudy">Cloudy</option>
                <option value="rain">Rain</option>
                <option value="storm">Storm</option>
                <option value="heatwave">Heatwave</option>
              </select>
            </div>
            <Toggle checked={params.signalOptimization} onChange={(v) => setParams({ ...params, signalOptimization: v })} label="Traffic Signal Optimization" />
            <Toggle checked={params.waterConservation} onChange={(v) => setParams({ ...params, waterConservation: v })} label="Water Conservation Measures" />
          </div>
        </Card>

        <Card className="lg:col-span-2">
          <SectionHeader title="Filters" icon={<Filter className="w-5 h-5" />} />
          <div className="flex flex-wrap gap-4 mb-4">
            <div>
              <span className="text-xs mirage-text-muted mb-1 block">Module</span>
              <select
                value={filterModule}
                onChange={(e) => setFilterModule(e.target.value)}
                className="px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700"
              >
                <option value="all">All Modules</option>
                <option value="traffic">Traffic</option>
                <option value="energy">Energy</option>
                <option value="water">Water</option>
              </select>
            </div>
            <div>
              <span className="text-xs mirage-text-muted mb-1 block">Risk Level</span>
              <select
                value={filterLevel}
                onChange={(e) => setFilterLevel(e.target.value)}
                className="px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700"
              >
                <option value="all">All Levels</option>
                <option value="critical">Critical</option>
                <option value="high">High</option>
                <option value="medium">Medium</option>
              </select>
            </div>
          </div>

          {filtered.length === 0 ? (
            <EmptyState message="No alerts match the current filters." icon={<ShieldAlert className="w-10 h-10" />} />
          ) : (
            <div className="space-y-3">
              {filtered.map((alert) => {
                const Icon = MODULE_ICONS[alert.module] || ShieldAlert;
                const color = MODULE_COLORS[alert.module] || '#0ea5e9';
                return (
                  <div key={alert.id} className="p-4 rounded-lg mirage-surface border border-slate-200 dark:border-slate-700">
                    <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
                      <div className="lg:col-span-1">
                        <div className="flex items-center gap-2 mb-2">
                          <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${color}15` }}>
                            <Icon className="w-5 h-5" style={{ color }} />
                          </div>
                          <div>
                            <p className="text-sm font-bold">{alert.zoneName}</p>
                            <p className="text-xs mirage-text-muted capitalize">{alert.module}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <RiskBadge level={alert.riskLevel} />
                          <span className="text-xs mirage-text-muted">Score: {alert.riskScore.toFixed(2)}</span>
                        </div>
                        <p className="text-xs mirage-text-muted mt-2">Confidence: <span className="font-medium capitalize">{alert.confidence}</span></p>
                        <p className="text-xs mirage-text-muted">Interval: {alert.predictedInterval}</p>
                      </div>

                      <div className="lg:col-span-2">
                        <p className="text-xs font-semibold mb-2">Contributing Factors</p>
                        <div className="space-y-2">
                          {alert.factors.map((f, i) => (
                            <div key={i} className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800/50">
                              <div className="flex items-center justify-between">
                                <span className="text-xs font-medium">{f.name}</span>
                                <span className="text-xs font-semibold" style={{ color }}>{f.value}</span>
                              </div>
                              <p className="text-xs mirage-text-muted mt-0.5">{f.contribution}</p>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="lg:col-span-1">
                        <p className="text-xs font-semibold mb-2">Recommended Action</p>
                        <div className="p-3 rounded-lg bg-sky-500/5 border border-sky-500/20">
                          <p className="text-sm">{alert.recommendedAction}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      </div>

      <Card>
        <SectionHeader title="Risk Thresholds" subtitle="Currently configured thresholds for risk classification" />
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-3 rounded-lg bg-amber-500/5">
            <p className="text-sm font-semibold text-amber-500 mb-2">Traffic (congestion ratio)</p>
            <p className="text-xs mirage-text-muted">Medium: {DEFAULT_THRESHOLDS.traffic.medium} | High: {DEFAULT_THRESHOLDS.traffic.high} | Critical: {DEFAULT_THRESHOLDS.traffic.critical}</p>
          </div>
          <div className="p-3 rounded-lg bg-red-500/5">
            <p className="text-sm font-semibold text-red-500 mb-2">Energy (supply gap ratio)</p>
            <p className="text-xs mirage-text-muted">Medium: {DEFAULT_THRESHOLDS.energy.medium} | High: {DEFAULT_THRESHOLDS.energy.high} | Critical: {DEFAULT_THRESHOLDS.energy.critical}</p>
          </div>
          <div className="p-3 rounded-lg bg-blue-500/5">
            <p className="text-sm font-semibold text-blue-500 mb-2">Water (supply gap ratio)</p>
            <p className="text-xs mirage-text-muted">Medium: {DEFAULT_THRESHOLDS.water.medium} | High: {DEFAULT_THRESHOLDS.water.high} | Critical: {DEFAULT_THRESHOLDS.water.critical}</p>
          </div>
        </div>
      </Card>

      <p className="text-xs mirage-text-muted text-center">
        Risk levels are calculated from ML model predictions (Random Forest) combined with threshold rules. Adjust the scenario controls above to see alerts update in real time.
      </p>
    </div>
  );
}
