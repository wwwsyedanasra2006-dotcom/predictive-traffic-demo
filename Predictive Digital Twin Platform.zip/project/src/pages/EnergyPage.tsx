import { useMemo, useState } from 'react';
import { Card, StatCard, SectionHeader, RiskBadge, Slider, Toggle, EmptyState } from '@/components/ui';
import { predictEnergy } from '@/lib/predictions';
import { getTrainedModels } from '@/lib/predictions';
import { randomForestFeatureImportance } from '@/lib/ml/randomForest';
import { generateExplanation } from '@/lib/riskEngine';
import { optimizeEnergyAllocation } from '@/lib/optimizationEngine';
import { DEFAULT_SCENARIO } from '@/lib/simulationEngine';
import type { ScenarioParams, EnergyPrediction } from '@/lib/types';
import { Zap, TrendingUp, AlertTriangle, Lightbulb, Brain } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar, Cell } from 'recharts';

export function EnergyPage() {
  const [params, setParams] = useState<ScenarioParams>({ ...DEFAULT_SCENARIO });
  const [selectedZone, setSelectedZone] = useState<string | null>(null);
  const predictions = useMemo(() => predictEnergy(params, 12), [params]);
  const models = useMemo(() => getTrainedModels(), []);
  const importance = useMemo(() => randomForestFeatureImportance(models.energy.rf), [models]);

  const isDark = document.documentElement.classList.contains('dark');
  const gridColor = isDark ? '#1e293b' : '#e2e8f0';
  const tickColor = isDark ? '#94a3b8' : '#64748b';

  const avgDemand = predictions.reduce((s, p) => s + p.predictedDemand, 0) / predictions.length;
  const avgSupply = predictions.reduce((s, p) => s + p.supply, 0) / predictions.length;
  const totalGap = predictions.reduce((s, p) => s + Math.max(0, p.supplyGap), 0);
  const highRisk = predictions.filter((p) => p.riskLevel === 'high' || p.riskLevel === 'critical');
  const selected: EnergyPrediction | undefined = selectedZone ? predictions.find((p) => p.zoneId === selectedZone) : predictions[0];

  const forecastData = selected?.forecast.map((f) => ({ hour: `${f.hour}:00`, demand: f.demand, supply: f.supply })) || [];
  const importanceData = importance.slice(0, 6).map((f) => ({ feature: f.feature, importance: Math.round(f.importance * 1000) / 10 }));
  const zoneBarData = predictions.map((p) => ({ name: p.zoneName, demand: Math.round(p.predictedDemand), supply: Math.round(p.supply), level: p.riskLevel }));
  const barColors: Record<string, string> = { low: '#10b981', medium: '#f59e0b', high: '#f97316', critical: '#ef4444' };

  const optimization = useMemo(() => {
    const demands = predictions.map((p) => ({ zoneId: p.zoneId, demand: p.predictedDemand }));
    return optimizeEnergyAllocation(demands, avgSupply * predictions.length);
  }, [predictions, avgSupply]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Energy Intelligence</h1>
        <p className="text-sm mirage-text-muted">Electricity demand and supply-risk prediction using Random Forest</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Avg Predicted Demand" value={avgDemand.toFixed(1)} unit="MW" icon={<Zap className="w-5 h-5" />} accentColor="#ef4444" />
        <StatCard label="Avg Supply" value={avgSupply.toFixed(1)} unit="MW" icon={<TrendingUp className="w-5 h-5" />} accentColor="#10b981" />
        <StatCard label="Total Supply Gap" value={totalGap.toFixed(1)} unit="MW" icon={<AlertTriangle className="w-5 h-5" />} accentColor="#f97316" />
        <StatCard label="High-Risk Zones" value={highRisk.length} icon={<AlertTriangle className="w-5 h-5" />} accentColor="#ef4444" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <SectionHeader title="Demand vs Supply Forecast" subtitle={selected ? `${selected.zoneName} — 12-hour prediction` : 'Select a zone'} icon={<TrendingUp className="w-5 h-5" />} />
          <div className="flex flex-wrap gap-2 mb-4">
            {predictions.map((p) => (
              <button
                key={p.zoneId}
                onClick={() => setSelectedZone(p.zoneId)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${selected?.zoneId === p.zoneId ? 'bg-sky-500 text-white' : 'mirage-surface'}`}
              >
                {p.zoneName}
              </button>
            ))}
          </div>
          {forecastData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={forecastData}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="hour" tick={{ fontSize: 10, fill: tickColor }} />
                <YAxis tick={{ fontSize: 10, fill: tickColor }} />
                <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
                <Line type="monotone" dataKey="demand" stroke="#ef4444" strokeWidth={2} dot={{ r: 3 }} name="Demand (MW)" />
                <Line type="monotone" dataKey="supply" stroke="#10b981" strokeWidth={2} strokeDasharray="5 5" dot={{ r: 3 }} name="Supply (MW)" />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState message="No forecast data available" />
          )}
        </Card>

        <Card>
          <SectionHeader title="Scenario Controls" />
          <div className="space-y-4">
            <Slider label="Energy Supply Change" value={params.energySupplyChange} min={-30} max={20} step={1} onChange={(v) => setParams({ ...params, energySupplyChange: v })} suffix="%" />
            <Slider label="Load Shedding" value={params.loadShedding} min={0} max={30} step={1} onChange={(v) => setParams({ ...params, loadShedding: v })} suffix="%" />
            <Slider label="Temperature Offset" value={params.temperatureOffset} min={-10} max={15} step={1} onChange={(v) => setParams({ ...params, temperatureOffset: v })} suffix="°C" />
            <div>
              <span className="text-sm font-medium mb-2 block">Weather Scenario</span>
              <select
                value={params.weatherScenario}
                onChange={(e) => setParams({ ...params, weatherScenario: e.target.value as ScenarioParams['weatherScenario'] })}
                className="w-full px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700"
              >
                <option value="clear">Clear</option>
                <option value="cloudy">Cloudy</option>
                <option value="rain">Rain</option>
                <option value="storm">Storm</option>
                <option value="heatwave">Heatwave</option>
              </select>
            </div>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <SectionHeader title="Zone Demand vs Supply" />
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={zoneBarData}>
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis dataKey="name" tick={{ fontSize: 9, fill: tickColor }} angle={-30} textAnchor="end" height={60} />
              <YAxis tick={{ fontSize: 10, fill: tickColor }} />
              <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="demand" fill="#ef4444" name="Demand (MW)" radius={[4, 4, 0, 0]} />
              <Bar dataKey="supply" fill="#10b981" name="Supply (MW)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <SectionHeader title="Feature Importance" icon={<Brain className="w-5 h-5" />} />
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={importanceData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis type="number" tick={{ fontSize: 10, fill: tickColor }} />
              <YAxis type="category" dataKey="feature" tick={{ fontSize: 10, fill: tickColor }} width={110} />
              <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="importance" fill="#0ea5e9" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {selected && (
        <Card>
          <SectionHeader title="Explainable AI" subtitle={`Why the prediction for ${selected.zoneName} was made`} icon={<Lightbulb className="w-5 h-5" />} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Risk Level:</span>
                <RiskBadge level={selected.riskLevel} />
              </div>
              <div className="text-sm mirage-text-muted">
                <p>Predicted demand: <span className="font-semibold text-slate-700 dark:text-slate-200">{selected.predictedDemand.toFixed(2)} MW</span></p>
                <p>Available supply: <span className="font-semibold text-slate-700 dark:text-slate-200">{selected.supply.toFixed(2)} MW</span></p>
                <p>Supply gap: <span className="font-semibold text-slate-700 dark:text-slate-200">{selected.supplyGap.toFixed(2)} MW</span></p>
              </div>
            </div>
            <div className="p-4 rounded-lg bg-sky-500/5 border border-sky-500/20">
              <div className="flex items-start gap-2">
                <Brain className="w-5 h-5 text-sky-500 shrink-0 mt-0.5" />
                <p className="text-sm">{generateExplanation('energy', selected.zoneId, params, importance)}</p>
              </div>
            </div>
          </div>
        </Card>
      )}

      <Card>
        <SectionHeader title="Energy Allocation Optimization" subtitle="Greedy resource allocation under supply constraints" />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="space-y-2">
            {optimization.allocation.map((a) => (
              <div key={a.zoneId} className="flex items-center justify-between p-3 rounded-lg bg-slate-100 dark:bg-slate-800/50">
                <div>
                  <span className="text-sm font-medium">{a.zoneName}</span>
                  <span className="text-xs mirage-text-muted ml-2">Priority {a.priority}</span>
                </div>
                <div className="text-right text-xs">
                  <span className="mirage-text-muted">Demand: {a.demand.toFixed(1)} → </span>
                  <span className="font-semibold text-emerald-500">Alloc: {a.allocated.toFixed(1)}</span>
                  {a.unmet > 0 && <span className="text-red-500 ml-1">Unmet: {a.unmet.toFixed(1)}</span>}
                </div>
              </div>
            ))}
          </div>
          <div className="p-4 rounded-lg bg-sky-500/5 border border-sky-500/20">
            <p className="text-sm">{optimization.explanation}</p>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <div className="text-center p-2 rounded-lg bg-red-500/10">
                <p className="text-xs mirage-text-muted">Baseline Unmet</p>
                <p className="text-lg font-bold text-red-500">{optimization.baselineUnmet.toFixed(1)}</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-amber-500/10">
                <p className="text-xs mirage-text-muted">Optimized Unmet</p>
                <p className="text-lg font-bold text-amber-500">{optimization.optimizedUnmet.toFixed(1)}</p>
              </div>
              <div className="text-center p-2 rounded-lg bg-emerald-500/10">
                <p className="text-xs mirage-text-muted">Improvement</p>
                <p className="text-lg font-bold text-emerald-500">{optimization.improvement.toFixed(1)}</p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      <p className="text-xs mirage-text-muted text-center">
        Predictions are generated by a Random Forest model trained on 21 days of synthetic energy data. This does not guarantee actual power failure predictions.
      </p>
    </div>
  );
}
