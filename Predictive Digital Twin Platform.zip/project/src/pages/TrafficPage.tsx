import { useMemo, useState } from 'react';
import { Card, StatCard, SectionHeader, RiskBadge, Slider, Toggle, EmptyState } from '@/components/ui';
import { predictTraffic } from '@/lib/predictions';
import { getTrainedModels } from '@/lib/predictions';
import { randomForestFeatureImportance } from '@/lib/ml/randomForest';
import { generateExplanation } from '@/lib/riskEngine';
import { DEFAULT_SCENARIO } from '@/lib/simulationEngine';
import type { ScenarioParams, CongestionPrediction } from '@/lib/types';
import { Car, TrendingUp, AlertTriangle, Lightbulb, Brain } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar, Cell } from 'recharts';

export function TrafficPage() {
  const [params, setParams] = useState<ScenarioParams>({ ...DEFAULT_SCENARIO });
  const [selectedZone, setSelectedZone] = useState<string | null>(null);
  const predictions = useMemo(() => predictTraffic(params, 12), [params]);
  const models = useMemo(() => getTrainedModels(), []);
  const importance = useMemo(() => randomForestFeatureImportance(models.traffic.rf), [models]);

  const isDark = document.documentElement.classList.contains('dark');
  const gridColor = isDark ? '#1e293b' : '#e2e8f0';
  const tickColor = isDark ? '#94a3b8' : '#64748b';

  const avgCongestion = predictions.reduce((s, p) => s + p.predictedCongestion, 0) / predictions.length;
  const highRisk = predictions.filter((p) => p.riskLevel === 'high' || p.riskLevel === 'critical');
  const selected: CongestionPrediction | undefined = selectedZone ? predictions.find((p) => p.zoneId === selectedZone) : predictions[0];

  const forecastData = selected?.forecast.map((f) => ({ hour: `${f.hour}:00`, congestion: f.value })) || [];
  const importanceData = importance.slice(0, 6).map((f) => ({ feature: f.feature, importance: Math.round(f.importance * 1000) / 10 }));
  const zoneBarData = predictions.map((p) => ({ name: p.zoneName, congestion: Math.round(p.predictedCongestion * 100), level: p.riskLevel }));

  const barColors: Record<string, string> = { low: '#10b981', medium: '#f59e0b', high: '#f97316', critical: '#ef4444' };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Traffic Intelligence</h1>
        <p className="text-sm mirage-text-muted">Congestion prediction using Random Forest on synthetic traffic data</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Avg Predicted Congestion" value={Math.round(avgCongestion * 100)} unit="%" icon={<Car className="w-5 h-5" />} accentColor="#f59e0b" />
        <StatCard label="High-Risk Zones" value={highRisk.length} icon={<AlertTriangle className="w-5 h-5" />} accentColor="#ef4444" />
        <StatCard label="Model" value="RF-15" subValue="15 trees, depth 7" icon={<Brain className="w-5 h-5" />} accentColor="#0ea5e9" />
        <StatCard label="Horizon" value="12h" subValue="hours ahead" icon={<TrendingUp className="w-5 h-5" />} accentColor="#10b981" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <SectionHeader title="Congestion Forecast" subtitle={selected ? `${selected.zoneName} — 12-hour prediction` : 'Select a zone'} icon={<TrendingUp className="w-5 h-5" />} />
          <div className="flex flex-wrap gap-2 mb-4">
            {predictions.map((p) => (
              <button
                key={p.zoneId}
                onClick={() => setSelectedZone(p.zoneId)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${selected?.zoneId === p.zoneId ? 'bg-sky-500 text-white' : 'mirage-surface'}`}
              >
                {p.zoneName}
              </button>
            ))}
          </div>
          {forecastData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={forecastData}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="hour" tick={{ fontSize: 10, fill: tickColor }} />
                <YAxis domain={[0, 1]} tick={{ fontSize: 10, fill: tickColor }} />
                <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
                <Line type="monotone" dataKey="congestion" stroke="#f59e0b" strokeWidth={2} dot={{ r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <EmptyState message="No forecast data available" />
          )}
        </Card>

        <Card>
          <SectionHeader title="Scenario Controls" subtitle="Adjust simulation parameters" />
          <div className="space-y-4">
            <Slider label="Traffic Volume" value={params.trafficMultiplier} min={0.5} max={2} step={0.05} onChange={(v) => setParams({ ...params, trafficMultiplier: v })} format={(v) => `${Math.round(v * 100)}%`} />
            <Slider label="Temperature Offset" value={params.temperatureOffset} min={-10} max={15} step={1} onChange={(v) => setParams({ ...params, temperatureOffset: v })} suffix="°C" />
            <div>
              <span className="text-sm font-medium mb-2 block">Weather Scenario</span>
              <select
                value={params.weatherScenario}
                onChange={(e) => setParams({ ...params, weatherScenario: e.target.value as ScenarioParams['weatherScenario'] })}
                className="w-full px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700"
              >
                <option value="clear">Clear</option>
                <option value="cloudy">Cloudy</option>
                <option value="rain">Rain</option>
                <option value="storm">Storm</option>
                <option value="heatwave">Heatwave</option>
              </select>
            </div>
            <Toggle checked={params.signalOptimization} onChange={(v) => setParams({ ...params, signalOptimization: v })} label="Signal Optimization" />
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <SectionHeader title="Zone Congestion Comparison" icon={<Car className="w-5 h-5" />} />
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={zoneBarData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis type="number" domain={[0, 100]} tick={{ fontSize: 10, fill: tickColor }} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: tickColor }} width={80} />
              <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="congestion" radius={[0, 4, 4, 0]}>
                {zoneBarData.map((entry, i) => (
                  <Cell key={i} fill={barColors[entry.level]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card>
          <SectionHeader title="Feature Importance" subtitle="What drives the model's predictions" icon={<Brain className="w-5 h-5" />} />
          <ResponsiveContainer width="100%" height={280}>
            <BarChart data={importanceData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
              <XAxis type="number" tick={{ fontSize: 10, fill: tickColor }} />
              <YAxis type="category" dataKey="feature" tick={{ fontSize: 10, fill: tickColor }} width={100} />
              <Tooltip contentStyle={{ background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 }} />
              <Bar dataKey="importance" fill="#0ea5e9" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>
      </div>

      {selected && (
        <Card>
          <SectionHeader title="Explainable AI" subtitle={`Why the prediction for ${selected.zoneName} was made`} icon={<Lightbulb className="w-5 h-5" />} />
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium">Risk Level:</span>
                <RiskBadge level={selected.riskLevel} />
              </div>
              <div className="text-sm mirage-text-muted">
                <p>Current congestion: <span className="font-semibold text-slate-700 dark:text-slate-200">{Math.round(selected.currentCongestion * 100)}%</span></p>
                <p>Predicted congestion: <span className="font-semibold text-slate-700 dark:text-slate-200">{Math.round(selected.predictedCongestion * 100)}%</span></p>
                <p className="mt-1">Model: {selected.modelUsed}</p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {Object.entries(selected.features).map(([k, v]) => (
                  <div key={k} className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800/50">
                    <span className="text-xs mirage-text-muted">{k}</span>
                    <p className="text-sm font-semibold">{typeof v === 'number' ? v.toFixed(2) : v}</p>
                  </div>
                ))}
              </div>
            </div>
            <div className="p-4 rounded-lg bg-sky-500/5 border border-sky-500/20">
              <div className="flex items-start gap-2">
                <Brain className="w-5 h-5 text-sky-500 shrink-0 mt-0.5" />
                <p className="text-sm">{generateExplanation('traffic', selected.zoneId, params, importance)}</p>
              </div>
              {selected.riskLevel !== 'low' && (
                <div className="mt-3 p-3 rounded-lg bg-amber-500/10">
                  <p className="text-xs font-medium text-amber-600 dark:text-amber-400">Recommended Action:</p>
                  <p className="text-sm mt-1">{selected.riskLevel === 'critical' ? 'Reroute traffic and adjust signal timing for peak hours' : 'Adjust signal timing and monitor for escalation'}</p>
                </div>
              )}
            </div>
          </div>
        </Card>
      )}

      <p className="text-xs mirage-text-muted text-center">
        Predictions are generated by a Random Forest model trained on 21 days of synthetic traffic data. Strong performance on synthetic data does not establish real-world predictive accuracy.
      </p>
    </div>
  );
}
