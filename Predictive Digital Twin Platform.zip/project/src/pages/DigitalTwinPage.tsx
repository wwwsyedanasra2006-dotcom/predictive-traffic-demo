import { useMemo } from 'react';
import { Card, SectionHeader, RiskBadge, ProgressBar } from '@/components/ui';
import { ZONES, ZONE_TYPE_COLORS, zoneTypeLabel } from '@/lib/zones';
import { predictTraffic, predictEnergy, predictWater } from '@/lib/predictions';
import { DEFAULT_SCENARIO } from '@/lib/simulationEngine';
import { MapPin, Car, Zap, Droplets } from 'lucide-react';

export function DigitalTwinPage() {
  const traffic = useMemo(() => predictTraffic(DEFAULT_SCENARIO, 6), []);
  const energy = useMemo(() => predictEnergy(DEFAULT_SCENARIO, 6), []);
  const water = useMemo(() => predictWater(DEFAULT_SCENARIO, 6), []);

  const gridPositions: Record<string, { col: number; row: number }> = {
    z1: { col: 2, row: 1 },
    z2: { col: 3, row: 1 },
    z3: { col: 1, row: 2 },
    z4: { col: 4, row: 2 },
    z5: { col: 1, row: 3 },
    z6: { col: 4, row: 3 },
    z7: { col: 2, row: 4 },
    z8: { col: 3, row: 4 },
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Digital Twin</h1>
        <p className="text-sm mirage-text-muted">Interactive schematic of the simulated city with live zone status</p>
      </div>

      <Card className="overflow-hidden">
        <SectionHeader title="City Grid Schematic" subtitle="8 zones across residential, commercial, industrial, and transport areas" icon={<MapPin className="w-5 h-5" />} />
        <div className="relative bg-slate-50 dark:bg-slate-900/50 rounded-xl p-6 min-h-[480px]">
          <div
            className="grid gap-4"
            style={{ gridTemplateColumns: 'repeat(4, 1fr)', gridTemplateRows: 'repeat(4, 1fr)', minHeight: '440px' }}
          >
            {ZONES.map((zone) => {
              const pos = gridPositions[zone.id];
              const t = traffic.find((p) => p.zoneId === zone.id);
              const e = energy.find((p) => p.zoneId === zone.id);
              const w = water.find((p) => p.zoneId === zone.id);
              const color = ZONE_TYPE_COLORS[zone.type];

              return (
                <div
                  key={zone.id}
                  className="relative rounded-xl border-2 p-4 flex flex-col gap-2 transition-all hover:scale-105 cursor-pointer"
                  style={{
                    gridColumn: pos.col,
                    gridRow: pos.row,
                    borderColor: `${color}40`,
                    background: `${color}08`,
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full" style={{ backgroundColor: color }} />
                    <span className="text-sm font-bold">{zone.name}</span>
                  </div>
                  <span className="text-[10px] mirage-text-muted uppercase tracking-wide">{zoneTypeLabel(zone.type)}</span>

                  <div className="space-y-1.5 mt-1">
                    <div className="flex items-center gap-1.5 text-xs">
                      <Car className="w-3 h-3 text-amber-500" />
                      <span className="mirage-text-muted">Traffic:</span>
                      <RiskBadge level={t?.riskLevel || 'low'} />
                    </div>
                    <div className="flex items-center gap-1.5 text-xs">
                      <Zap className="w-3 h-3 text-red-500" />
                      <span className="mirage-text-muted">Energy:</span>
                      <RiskBadge level={e?.riskLevel || 'low'} />
                    </div>
                    <div className="flex items-center gap-1.5 text-xs">
                      <Droplets className="w-3 h-3 text-blue-500" />
                      <span className="mirage-text-muted">Water:</span>
                      <RiskBadge level={w?.riskLevel || 'low'} />
                    </div>
                  </div>

                  <div className="mt-1 space-y-1">
                    <div>
                      <span className="text-[10px] mirage-text-muted">Congestion</span>
                      <ProgressBar value={t?.predictedCongestion || 0} max={1} color="#f59e0b" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <SectionHeader title="Traffic Status" icon={<Car className="w-5 h-5" />} />
          <div className="space-y-3">
            {traffic.map((t) => (
              <div key={t.zoneId} className="flex items-center justify-between text-sm">
                <span className="font-medium">{t.zoneName}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs mirage-text-muted">{Math.round(t.predictedCongestion * 100)}%</span>
                  <RiskBadge level={t.riskLevel} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionHeader title="Energy Status" icon={<Zap className="w-5 h-5" />} />
          <div className="space-y-3">
            {energy.map((e) => (
              <div key={e.zoneId} className="flex items-center justify-between text-sm">
                <span className="font-medium">{e.zoneName}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs mirage-text-muted">{e.predictedDemand.toFixed(1)}/{e.supply.toFixed(1)} MW</span>
                  <RiskBadge level={e.riskLevel} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionHeader title="Water Status" icon={<Droplets className="w-5 h-5" />} />
          <div className="space-y-3">
            {water.map((w) => (
              <div key={w.zoneId} className="flex items-center justify-between text-sm">
                <span className="font-medium">{w.zoneName}</span>
                <div className="flex items-center gap-2">
                  <span className="text-xs mirage-text-muted">{w.predictedDemand.toFixed(1)}/{w.supply.toFixed(1)} ML</span>
                  <RiskBadge level={w.riskLevel} />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
      <p className="text-xs mirage-text-muted text-center">
        Zone status badges are computed from Random Forest model predictions on synthetic data. This is a simulation, not live sensor data.
      </p>
    </div>
  );
}
