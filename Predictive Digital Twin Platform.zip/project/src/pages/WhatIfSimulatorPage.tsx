import { useMemo, useState } from 'react';
import { Card, StatCard, SectionHeader, Slider, Toggle, Button } from '@/components/ui';
import { runScenario, DEFAULT_SCENARIO } from '@/lib/simulationEngine';
import { detectRisks } from '@/lib/riskEngine';
import { downloadFullReport } from '@/lib/export';
import type { ScenarioParams } from '@/lib/types';
import { SlidersHorizontal, Car, Zap, Droplets, Download, RotateCcw } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from 'recharts';

export function WhatIfSimulatorPage() {
  const [params, setParams] = useState<ScenarioParams>({ ...DEFAULT_SCENARIO });
  const result = useMemo(() => runScenario(params), [params]);
  const alerts = useMemo(() => detectRisks(params), [params]);

  const isDark = document.documentElement.classList.contains('dark');
  const gridColor = isDark ? '#1e293b' : '#e2e8f0';
  const tickColor = isDark ? '#94a3b8' : '#64748b';

  const trafficChartData = result.traffic.labels.map((label, i) => ({
    hour: label,
    baseline: result.traffic.baseline[i],
    modified: result.traffic.modified[i],
  }));
  const energyChartData = result.energy.labels.map((label, i) => ({
    hour: label,
    baseline: result.energy.baselineDemand[i],
    modified: result.energy.modifiedDemand[i],
    supply: result.energy.supply[i],
  }));
  const waterChartData = result.water.labels.map((label, i) => ({
    hour: label,
    baseline: result.water.baselineDemand[i],
    modified: result.water.modifiedDemand[i],
    supply: result.water.supply[i],
  }));

  const tooltipStyle = { background: isDark ? '#0f172a' : '#fff', border: `1px solid ${gridColor}`, borderRadius: 8, fontSize: 12 };

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold">What-If Simulator</h1>
          <p className="text-sm mirage-text-muted">Modify parameters and compare baseline vs modified scenarios in real time</p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" size="sm" onClick={() => setParams({ ...DEFAULT_SCENARIO })} >
            <span className="flex items-center gap-1.5"><RotateCcw className="w-3.5 h-3.5" /> Reset</span>
          </Button>
          <Button variant="primary" size="sm" onClick={() => downloadFullReport(params, result, alerts, null, 'Random Forest (15 trees)')}>
            <span className="flex items-center gap-1.5"><Download className="w-3.5 h-3.5" /> Export CSV</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Overall Risk Reduction" value={result.summary.overallRiskReduction} unit="%" icon={<SlidersHorizontal className="w-5 h-5" />} accentColor="#0ea5e9" />
        <StatCard label="Traffic Improvement" value={result.summary.trafficImprovement.toFixed(2)} icon={<Car className="w-5 h-5" />} accentColor="#f59e0b" />
        <StatCard label="Energy Savings" value={result.summary.energySavings.toFixed(1)} unit="MW" icon={<Zap className="w-5 h-5" />} accentColor="#ef4444" />
        <StatCard label="Water Savings" value={result.summary.waterSavings.toFixed(1)} unit="ML" icon={<Droplets className="w-5 h-5" />} accentColor="#3b82f6" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card>
          <SectionHeader title="Scenario Parameters" subtitle="Adjust and see results update instantly" icon={<SlidersHorizontal className="w-5 h-5" />} />
          <div className="space-y-4">
            <Slider label="Traffic Volume" value={params.trafficMultiplier} min={0.5} max={2} step={0.05} onChange={(v) => setParams({ ...params, trafficMultiplier: v })} format={(v) => `${Math.round(v * 100)}%`} />
            <Slider label="Energy Supply Change" value={params.energySupplyChange} min={-30} max={20} step={1} onChange={(v) => setParams({ ...params, energySupplyChange: v })} suffix="%" />
            <Slider label="Water Demand Change" value={params.waterDemandChange} min={-30} max={50} step={1} onChange={(v) => setParams({ ...params, waterDemandChange: v })} suffix="%" />
            <Slider label="Temperature Offset" value={params.temperatureOffset} min={-10} max={15} step={1} onChange={(v) => setParams({ ...params, temperatureOffset: v })} suffix="°C" />
            <Slider label="Load Shedding" value={params.loadShedding} min={0} max={30} step={1} onChange={(v) => setParams({ ...params, loadShedding: v })} suffix="%" />
            <div>
              <span className="text-sm font-medium mb-2 block">Weather Scenario</span>
              <select
                value={params.weatherScenario}
                onChange={(e) => setParams({ ...params, weatherScenario: e.target.value as ScenarioParams['weatherScenario'] })}
                className="w-full px-3 py-2 rounded-lg text-sm mirage-surface border border-slate-200 dark:border-slate-700"
              >
                <option value="clear">Clear</option>
                <option value="cloudy">Cloudy</option>
                <option value="rain">Rain</option>
                <option value="storm">Storm</option>
                <option value="heatwave">Heatwave</option>
              </select>
            </div>
            <Toggle checked={params.signalOptimization} onChange={(v) => setParams({ ...params, signalOptimization: v })} label="Traffic Signal Optimization" />
            <Toggle checked={params.waterConservation} onChange={(v) => setParams({ ...params, waterConservation: v })} label="Water Conservation Measures" />
          </div>
        </Card>

        <div className="lg:col-span-2 space-y-4">
          <Card>
            <SectionHeader title="Traffic: Baseline vs Modified" subtitle={`Avg: ${result.traffic.avgBaseline.toFixed(2)} → ${result.traffic.avgModified.toFixed(2)} | Risk reduction: ${result.traffic.riskReduction}%`} icon={<Car className="w-5 h-5" />} />
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={trafficChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="hour" tick={{ fontSize: 9, fill: tickColor }} interval={3} />
                <YAxis domain={[0, 1]} tick={{ fontSize: 10, fill: tickColor }} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="baseline" stroke="#94a3b8" strokeWidth={2} strokeDasharray="5 5" name="Baseline" dot={false} />
                <Line type="monotone" dataKey="modified" stroke="#f59e0b" strokeWidth={2} name="Modified" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          <Card>
            <SectionHeader title="Energy: Baseline vs Modified" subtitle={`Avg demand: ${result.energy.avgBaseline.toFixed(1)} → ${result.energy.avgModified.toFixed(1)} MW | Gap: ${result.energy.supplyGapBaseline.toFixed(1)} → ${result.energy.supplyGapModified.toFixed(1)}`} icon={<Zap className="w-5 h-5" />} />
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={energyChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="hour" tick={{ fontSize: 9, fill: tickColor }} interval={3} />
                <YAxis tick={{ fontSize: 10, fill: tickColor }} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="baseline" stroke="#94a3b8" strokeWidth={2} strokeDasharray="5 5" name="Baseline Demand" dot={false} />
                <Line type="monotone" dataKey="modified" stroke="#ef4444" strokeWidth={2} name="Modified Demand" dot={false} />
                <Line type="monotone" dataKey="supply" stroke="#10b981" strokeWidth={2} strokeDasharray="3 3" name="Supply" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </Card>

          <Card>
            <SectionHeader title="Water: Baseline vs Modified" subtitle={`Avg demand: ${result.water.avgBaseline.toFixed(1)} → ${result.water.avgModified.toFixed(1)} ML | Gap: ${result.water.supplyGapBaseline.toFixed(1)} → ${result.water.supplyGapModified.toFixed(1)}`} icon={<Droplets className="w-5 h-5" />} />
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={waterChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke={gridColor} />
                <XAxis dataKey="hour" tick={{ fontSize: 9, fill: tickColor }} interval={3} />
                <YAxis tick={{ fontSize: 10, fill: tickColor }} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
                <Line type="monotone" dataKey="baseline" stroke="#94a3b8" strokeWidth={2} strokeDasharray="5 5" name="Baseline Demand" dot={false} />
                <Line type="monotone" dataKey="modified" stroke="#3b82f6" strokeWidth={2} name="Modified Demand" dot={false} />
                <Line type="monotone" dataKey="supply" stroke="#06b6d4" strokeWidth={2} strokeDasharray="3 3" name="Supply" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </div>
      </div>

      <Card>
        <SectionHeader title="Scenario Comparison Summary" subtitle="Baseline vs modified — what changed and why" />
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700">
                <th className="text-left py-2 px-3 font-semibold">Metric</th>
                <th className="text-right py-2 px-3 font-semibold">Baseline</th>
                <th className="text-right py-2 px-3 font-semibold">Modified</th>
                <th className="text-right py-2 px-3 font-semibold">Change</th>
                <th className="text-center py-2 px-3 font-semibold">Type</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b border-slate-100 dark:border-slate-800">
                <td className="py-2 px-3">Traffic Avg Congestion</td>
                <td className="text-right py-2 px-3">{result.traffic.avgBaseline.toFixed(3)}</td>
                <td className="text-right py-2 px-3">{result.traffic.avgModified.toFixed(3)}</td>
                <td className="text-right py-2 px-3 font-semibold" style={{ color: result.traffic.avgModified < result.traffic.avgBaseline ? '#10b981' : '#ef4444' }}>
                  {(result.traffic.avgModified - result.traffic.avgBaseline).toFixed(3)}
                </td>
                <td className="text-center py-2 px-3 text-xs mirage-text-muted">Simulation</td>
              </tr>
              <tr className="border-b border-slate-100 dark:border-slate-800">
                <td className="py-2 px-3">Energy Avg Demand (MW)</td>
                <td className="text-right py-2 px-3">{result.energy.avgBaseline.toFixed(1)}</td>
                <td className="text-right py-2 px-3">{result.energy.avgModified.toFixed(1)}</td>
                <td className="text-right py-2 px-3 font-semibold" style={{ color: result.energy.avgModified < result.energy.avgBaseline ? '#10b981' : '#ef4444' }}>
                  {(result.energy.avgModified - result.energy.avgBaseline).toFixed(1)}
                </td>
                <td className="text-center py-2 px-3 text-xs mirage-text-muted">Simulation</td>
              </tr>
              <tr className="border-b border-slate-100 dark:border-slate-800">
                <td className="py-2 px-3">Energy Supply Gap (MW)</td>
                <td className="text-right py-2 px-3">{result.energy.supplyGapBaseline.toFixed(1)}</td>
                <td className="text-right py-2 px-3">{result.energy.supplyGapModified.toFixed(1)}</td>
                <td className="text-right py-2 px-3 font-semibold" style={{ color: result.energy.supplyGapModified < result.energy.supplyGapBaseline ? '#10b981' : '#ef4444' }}>
                  {(result.energy.supplyGapModified - result.energy.supplyGapBaseline).toFixed(1)}
                </td>
                <td className="text-center py-2 px-3 text-xs mirage-text-muted">Calculation</td>
              </tr>
              <tr className="border-b border-slate-100 dark:border-slate-800">
                <td className="py-2 px-3">Water Avg Demand (ML)</td>
                <td className="text-right py-2 px-3">{result.water.avgBaseline.toFixed(1)}</td>
                <td className="text-right py-2 px-3">{result.water.avgModified.toFixed(1)}</td>
                <td className="text-right py-2 px-3 font-semibold" style={{ color: result.water.avgModified < result.water.avgBaseline ? '#10b981' : '#ef4444' }}>
                  {(result.water.avgModified - result.water.avgBaseline).toFixed(1)}
                </td>
                <td className="text-center py-2 px-3 text-xs mirage-text-muted">Simulation</td>
              </tr>
              <tr className="border-b border-slate-100 dark:border-slate-800">
                <td className="py-2 px-3">Water Supply Gap (ML)</td>
                <td className="text-right py-2 px-3">{result.water.supplyGapBaseline.toFixed(1)}</td>
                <td className="text-right py-2 px-3">{result.water.supplyGapModified.toFixed(1)}</td>
                <td className="text-right py-2 px-3 font-semibold" style={{ color: result.water.supplyGapModified < result.water.supplyGapBaseline ? '#10b981' : '#ef4444' }}>
                  {(result.water.supplyGapModified - result.water.supplyGapBaseline).toFixed(1)}
                </td>
                <td className="text-center py-2 px-3 text-xs mirage-text-muted">Calculation</td>
              </tr>
              <tr>
                <td className="py-2 px-3">Active Risk Alerts</td>
                <td className="text-right py-2 px-3">—</td>
                <td className="text-right py-2 px-3">{alerts.length}</td>
                <td className="text-right py-2 px-3 font-semibold text-amber-500">{alerts.length}</td>
                <td className="text-center py-2 px-3 text-xs mirage-text-muted">ML + Thresholds</td>
              </tr>
            </tbody>
          </table>
        </div>
      </Card>

      <p className="text-xs mirage-text-muted text-center">
        Baseline = clear weather, no interventions. Modified = your scenario parameters. Charts labeled "Simulation" use deterministic rules; "ML" outputs come from the Random Forest model.
      </p>
    </div>
  );
}
