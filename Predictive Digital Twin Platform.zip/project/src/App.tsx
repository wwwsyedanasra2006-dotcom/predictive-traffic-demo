import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { ThemeProvider } from '@/hooks/useTheme';
import { Sidebar } from '@/components/Sidebar';
import { OverviewPage } from '@/pages/OverviewPage';
import { DigitalTwinPage } from '@/pages/DigitalTwinPage';
import { TrafficPage } from '@/pages/TrafficPage';
import { EnergyPage } from '@/pages/EnergyPage';
import { WaterPage } from '@/pages/WaterPage';
import { WhatIfSimulatorPage } from '@/pages/WhatIfSimulatorPage';
import { RiskCenterPage } from '@/pages/RiskCenterPage';
import { OptimizationLabPage } from '@/pages/OptimizationLabPage';
import { SimulationHistoryPage } from '@/pages/SimulationHistoryPage';
import { ModelEvaluationPage } from '@/pages/ModelEvaluationPage';
import { SettingsPage } from '@/pages/SettingsPage';
import type { PageId } from '@/lib/types';

function AppContent() {
  const [currentPage, setCurrentPage] = useState<PageId>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  function renderPage() {
    switch (currentPage) {
      case 'overview': return <OverviewPage />;
      case 'digital-twin': return <DigitalTwinPage />;
      case 'traffic': return <TrafficPage />;
      case 'energy': return <EnergyPage />;
      case 'water': return <WaterPage />;
      case 'what-if': return <WhatIfSimulatorPage />;
      case 'risk': return <RiskCenterPage />;
      case 'optimization': return <OptimizationLabPage />;
      case 'history': return <SimulationHistoryPage />;
      case 'evaluation': return <ModelEvaluationPage />;
      case 'settings': return <SettingsPage />;
      default: return <OverviewPage />;
    }
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <main className="flex-1 overflow-y-auto mirage-scrollbar">
        <div className="md:hidden flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-700 sticky top-0 z-20 bg-inherit">
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <span className="text-sm font-bold tracking-wide">MIRAGE</span>
        </div>
        <div className="p-4 md:p-6 max-w-7xl mx-auto">
          {renderPage()}
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}

export default App;
