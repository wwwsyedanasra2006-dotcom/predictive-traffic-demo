export type PageId =
  | 'overview'
  | 'digital-twin'
  | 'traffic'
  | 'energy'
  | 'water'
  | 'what-if'
  | 'risk'
  | 'optimization'
  | 'history'
  | 'evaluation'
  | 'settings';

export type ZoneType = 'residential' | 'commercial' | 'industrial' | 'transport';

export interface Zone {
  id: string;
  name: string;
  type: ZoneType;
  population: number;
  area: number;
  roadCapacity: number;
  powerSupply: number;
  waterSupply: number;
}

export type WeatherCondition = 'clear' | 'cloudy' | 'rain' | 'storm' | 'heatwave';

export interface TrafficRecord {
  timestamp: number;
  zoneId: string;
  zoneType: ZoneType;
  vehicleCount: number;
  avgSpeed: number;
  roadCapacity: number;
  weather: WeatherCondition;
  dayOfWeek: number;
  hour: number;
  congestion: number;
}

export interface EnergyRecord {
  timestamp: number;
  zoneId: string;
  zoneType: ZoneType;
  hour: number;
  dayOfWeek: number;
  temperature: number;
  historicalDemand: number;
  supply: number;
  demand: number;
}

export interface WaterRecord {
  timestamp: number;
  zoneId: string;
  zoneType: ZoneType;
  hour: number;
  dayOfWeek: number;
  temperature: number;
  population: number;
  weather: WeatherCondition;
  reservoirLevel: number;
  supply: number;
  demand: number;
}

export interface CongestionPrediction {
  zoneId: string;
  zoneName: string;
  currentCongestion: number;
  predictedCongestion: number;
  forecast: { hour: number; value: number }[];
  riskLevel: RiskLevel;
  modelUsed: string;
  features: Record<string, number>;
}

export interface EnergyPrediction {
  zoneId: string;
  zoneName: string;
  currentDemand: number;
  predictedDemand: number;
  supply: number;
  supplyGap: number;
  forecast: { hour: number; demand: number; supply: number }[];
  riskLevel: RiskLevel;
  modelUsed: string;
  features: Record<string, number>;
}

export interface WaterPrediction {
  zoneId: string;
  zoneName: string;
  currentDemand: number;
  predictedDemand: number;
  supply: number;
  supplyGap: number;
  forecast: { hour: number; demand: number; supply: number }[];
  riskLevel: RiskLevel;
  modelUsed: string;
  features: Record<string, number>;
}

export type RiskLevel = 'low' | 'medium' | 'high' | 'critical';

export interface RiskAlert {
  id: string;
  module: 'traffic' | 'energy' | 'water';
  zoneId: string;
  zoneName: string;
  riskLevel: RiskLevel;
  riskScore: number;
  factors: { name: string; value: string; contribution: string }[];
  predictedInterval: string;
  recommendedAction: string;
  confidence: 'low' | 'moderate' | 'high';
}

export interface ScenarioParams {
  trafficMultiplier: number;
  energySupplyChange: number;
  waterDemandChange: number;
  weatherScenario: WeatherCondition;
  temperatureOffset: number;
  signalOptimization: boolean;
  waterConservation: boolean;
  loadShedding: number;
}

export interface ScenarioResult {
  traffic: {
    baseline: number[];
    modified: number[];
    labels: string[];
    avgBaseline: number;
    avgModified: number;
    riskReduction: number;
  };
  energy: {
    baselineDemand: number[];
    modifiedDemand: number[];
    supply: number[];
    labels: string[];
    avgBaseline: number;
    avgModified: number;
    supplyGapBaseline: number;
    supplyGapModified: number;
    riskReduction: number;
  };
  water: {
    baselineDemand: number[];
    modifiedDemand: number[];
    supply: number[];
    labels: string[];
    avgBaseline: number;
    avgModified: number;
    supplyGapBaseline: number;
    supplyGapModified: number;
    riskReduction: number;
  };
  summary: {
    overallRiskReduction: number;
    energySavings: number;
    waterSavings: number;
    trafficImprovement: number;
  };
}

export interface OptimizationResult {
  module: 'energy' | 'water';
  totalResource: number;
  totalDemand: number;
  allocation: { zoneId: string; zoneName: string; demand: number; allocated: number; unmet: number; priority: number }[];
  objectiveValue: number;
  totalUnmet: number;
  explanation: string;
  baselineUnmet: number;
  optimizedUnmet: number;
  improvement: number;
}

export interface ModelMetrics {
  mae: number;
  rmse: number;
  r2: number;
  baselineMae: number;
  baselineRmse: number;
  baselineR2: number;
  trainSize: number;
  testSize: number;
  featureNames: string[];
  featureImportance: { feature: string; importance: number }[];
  actualVsPredicted: { actual: number; predicted: number; baseline: number }[];
  modelName: string;
  baselineName: string;
}

export interface SavedSimulation {
  id: string;
  name: string;
  module: string;
  scenario_params: ScenarioParams;
  baseline_results: ScenarioResult;
  modified_results: ScenarioResult;
  risk_alerts: RiskAlert[];
  optimization_result: OptimizationResult | null;
  notes: string;
  created_at: string;
}

export interface DashboardSummary {
  totalZones: number;
  traffic: { avgCongestion: number; highRiskZones: number };
  energy: { avgDemand: number; avgSupply: number; supplyGap: number; highRiskZones: number };
  water: { avgDemand: number; avgSupply: number; supplyGap: number; highRiskZones: number };
  activeAlerts: number;
  criticalAlerts: number;
  simulationTime: string;
  zones: Zone[];
}
