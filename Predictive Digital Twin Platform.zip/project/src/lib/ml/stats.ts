export function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

export function std(arr: number[]): number {
  if (arr.length < 2) return 0;
  const m = mean(arr);
  const variance = arr.reduce((s, v) => s + (v - m) ** 2, 0) / (arr.length - 1);
  return Math.sqrt(variance);
}

export function mae(actual: number[], predicted: number[]): number {
  if (actual.length === 0) return 0;
  let s = 0;
  for (let i = 0; i < actual.length; i++) s += Math.abs(actual[i] - predicted[i]);
  return s / actual.length;
}

export function rmse(actual: number[], predicted: number[]): number {
  if (actual.length === 0) return 0;
  let s = 0;
  for (let i = 0; i < actual.length; i++) s += (actual[i] - predicted[i]) ** 2;
  return Math.sqrt(s / actual.length);
}

export function r2Score(actual: number[], predicted: number[]): number {
  if (actual.length === 0) return 0;
  const m = mean(actual);
  let ssRes = 0;
  let ssTot = 0;
  for (let i = 0; i < actual.length; i++) {
    ssRes += (actual[i] - predicted[i]) ** 2;
    ssTot += (actual[i] - m) ** 2;
  }
  if (ssTot === 0) return 0;
  return 1 - ssRes / ssTot;
}

export interface DataSplit {
  xTrain: number[][];
  yTrain: number[];
  xTest: number[][];
  yTest: number[];
  trainIndices: number[];
  testIndices: number[];
}

export function chronologicalSplit(
  X: number[][],
  y: number[],
  testRatio: number = 0.2
): DataSplit {
  const n = X.length;
  const splitIdx = Math.floor(n * (1 - testRatio));
  const indices = Array.from({ length: n }, (_, i) => i);
  const trainIndices = indices.slice(0, splitIdx);
  const testIndices = indices.slice(splitIdx);
  return {
    xTrain: X.slice(0, splitIdx),
    yTrain: y.slice(0, splitIdx),
    xTest: X.slice(splitIdx),
    yTest: y.slice(splitIdx),
    trainIndices,
    testIndices,
  };
}

export function normalizeColumn(X: number[][], colIdx: number): { scaled: number[][]; mean: number; std: number } {
  const col = X.map((r) => r[colIdx]);
  const m = mean(col);
  const s = std(col) || 1;
  const scaled = X.map((r) => {
    const copy = [...r];
    copy[colIdx] = (copy[colIdx] - m) / s;
    return copy;
  });
  return { scaled, mean: m, std: s };
}
