import { trainDecisionTree, predictTree, type TreeNode } from './decisionTree';

export interface RandomForestModel {
  trees: TreeNode[];
  featureNames: string[];
  featureMeans: number[];
  featureStds: number[];
  nEstimators: number;
  maxDepth: number;
}

function mulberry32(seed: number) {
  let a = seed;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function bootstrapSample(
  X: number[][],
  y: number[],
  rng: () => number,
  sampleRatio: number = 0.7
): { X: number[][]; y: number[] } {
  const n = X.length;
  const sampleSize = Math.floor(n * sampleRatio);
  const sampleX: number[][] = [];
  const sampleY: number[] = [];
  for (let i = 0; i < sampleSize; i++) {
    const idx = Math.floor(rng() * n);
    sampleX.push(X[idx]);
    sampleY.push(y[idx]);
  }
  return { X: sampleX, y: sampleY };
}

function sampleFeatures(
  X: number[][],
  featureCount: number,
  rng: () => number
): { X: number[][]; featureIndices: number[] } {
  const allIndices = Array.from({ length: featureCount }, (_, i) => i);
  for (let i = allIndices.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [allIndices[i], allIndices[j]] = [allIndices[j], allIndices[i]];
  }
  const sqrtFeatures = Math.max(1, Math.floor(Math.sqrt(featureCount)));
  const selected = allIndices.slice(0, sqrtFeatures);
  const subX = X.map((row) => selected.map((idx) => row[idx]));
  return { X: subX, featureIndices: selected };
}

export function trainRandomForest(
  X: number[][],
  y: number[],
  featureNames: string[],
  featureMeans: number[],
  featureStds: number[],
  nEstimators: number = 20,
  maxDepth: number = 7,
  seed: number = 42
): RandomForestModel {
  const rng = mulberry32(seed);
  const featureCount = X[0].length;
  const trees: TreeNode[] = [];

  for (let i = 0; i < nEstimators; i++) {
    const { X: bootX, y: bootY } = bootstrapSample(X, y, rng, 0.7);
    const { X: subX, featureIndices } = sampleFeatures(bootX, featureCount, rng);
    const tree = trainDecisionTree(subX, bootY, maxDepth, 5, 0);
    (tree as any)._featureIndices = featureIndices;
    trees.push(tree);
  }

  return { trees, featureNames, featureMeans, featureStds, nEstimators, maxDepth };
}

export function predictRandomForest(model: RandomForestModel, x: number[]): number {
  let sum = 0;
  for (const tree of model.trees) {
    const featureIndices = (tree as any)._featureIndices as number[];
    const subX = featureIndices.map((idx: number) => x[idx]);
    sum += predictTree(tree, subX);
  }
  return sum / model.trees.length;
}

export function randomForestFeatureImportance(
  model: RandomForestModel
): { feature: string; importance: number }[] {
  const accum: Record<number, number> = {};
  let totalGain = 0;

  for (const tree of model.trees) {
    const featureIndices = (tree as any)._featureIndices as number[];
    const nodeSamples = tree.samples || 1;

    function traverse(n: any) {
      if (n.isLeaf) return;
      const originalFeature = featureIndices[n.split.feature];
      const gain = n.split.gain * (n.samples || 1);
      if (!accum[originalFeature]) accum[originalFeature] = 0;
      accum[originalFeature] += gain;
      totalGain += gain;
      traverse(n.left);
      traverse(n.right);
    }
    traverse(tree);
  }

  if (totalGain === 0) {
    return model.featureNames.map((name) => ({ feature: name, importance: 0 }));
  }

  return model.featureNames.map((name, i) => ({
    feature: name,
    importance: (accum[i] || 0) / totalGain,
  })).sort((a, b) => b.importance - a.importance);
}
