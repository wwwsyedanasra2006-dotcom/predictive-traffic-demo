export interface SplitInfo {
  feature: number;
  threshold: number;
  gain: number;
}

export interface TreeNode {
  isLeaf: boolean;
  prediction?: number;
  split?: SplitInfo;
  left?: TreeNode;
  right?: TreeNode;
  samples?: number;
}

function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

function variance(arr: number[]): number {
  if (arr.length < 2) return 0;
  const m = mean(arr);
  return arr.reduce((s, v) => s + (v - m) ** 2, 0) / arr.length;
}

function bestSplit(X: number[][], y: number[], featureIdx: number): SplitInfo | null {
  const n = X.length;
  if (n < 4) return null;
  const values = X.map((r) => r[featureIdx]).sort((a, b) => a - b);
  const parentVar = variance(y);
  let bestGain = 0;
  let bestThreshold = 0;
  let found = false;

  for (let i = 1; i < n; i += Math.max(1, Math.floor(n / 30))) {
    const threshold = (values[i] + values[i - 1]) / 2;
    const leftY: number[] = [];
    const rightY: number[] = [];
    for (let j = 0; j < n; j++) {
      if (X[j][featureIdx] <= threshold) leftY.push(y[j]);
      else rightY.push(y[j]);
    }
    if (leftY.length < 2 || rightY.length < 2) continue;
    const gain = parentVar - (leftY.length / n) * variance(leftY) - (rightY.length / n) * variance(rightY);
    if (gain > bestGain) {
      bestGain = gain;
      bestThreshold = threshold;
      found = true;
    }
  }
  return found ? { feature: featureIdx, threshold: bestThreshold, gain: bestGain } : null;
}

export function trainDecisionTree(
  X: number[][],
  y: number[],
  maxDepth: number = 6,
  minSamples: number = 5,
  depth: number = 0
): TreeNode {
  if (depth >= maxDepth || X.length < minSamples || variance(y) < 0.0001) {
    return { isLeaf: true, prediction: mean(y), samples: X.length };
  }

  let best: SplitInfo | null = null;
  let bestFeatureIdx = 0;
  for (let f = 0; f < X[0].length; f++) {
    const split = bestSplit(X, y, f);
    if (split && (!best || split.gain > best.gain)) {
      best = split;
      bestFeatureIdx = f;
    }
  }

  if (!best || best.gain <= 0) {
    return { isLeaf: true, prediction: mean(y), samples: X.length };
  }

  const leftX: number[][] = [];
  const leftY: number[] = [];
  const rightX: number[][] = [];
  const rightY: number[] = [];
  for (let i = 0; i < X.length; i++) {
    if (X[i][bestFeatureIdx] <= best.threshold) {
      leftX.push(X[i]);
      leftY.push(y[i]);
    } else {
      rightX.push(X[i]);
      rightY.push(y[i]);
    }
  }

  return {
    isLeaf: false,
    split: best,
    left: trainDecisionTree(leftX, leftY, maxDepth, minSamples, depth + 1),
    right: trainDecisionTree(rightX, rightY, maxDepth, minSamples, depth + 1),
    samples: X.length,
  };
}

export function predictTree(node: TreeNode, x: number[]): number {
  if (node.isLeaf) return node.prediction!;
  if (x[node.split!.feature] <= node.split!.threshold) return predictTree(node.left!, x);
  return predictTree(node.right!, x);
}

export function treeFeatureImportance(node: TreeNode, featureNames: string[], totalSamples: number): { feature: string; importance: number }[] {
  const importances: Record<number, number> = {};
  function traverse(n: TreeNode) {
    if (n.isLeaf) return;
    if (!importances[n.split!.feature]) importances[n.split!.feature] = 0;
    importances[n.split!.feature] += (n.split!.gain * n.samples!) / totalSamples;
    traverse(n.left!);
    traverse(n.right!);
  }
  traverse(node);
  return featureNames.map((name, i) => ({
    feature: name,
    importance: importances[i] || 0,
  })).sort((a, b) => b.importance - a.importance);
}
