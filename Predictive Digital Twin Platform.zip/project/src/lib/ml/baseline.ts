export interface PersistenceBaseline {
  type: 'persistence' | 'historical_average';
  historicalAvg: number;
  lastValue: number;
  featureNames: string[];
}

export function trainPersistenceBaseline(y: number[], featureNames: string[]): PersistenceBaseline {
  const lastValue = y.length > 0 ? y[y.length - 1] : 0;
  const historicalAvg = y.length > 0 ? y.reduce((a, b) => a + b, 0) / y.length : 0;
  return { type: 'persistence', historicalAvg, lastValue, featureNames };
}

export function predictPersistence(model: PersistenceBaseline, x: number[]): number {
  void x;
  return (model.lastValue + model.historicalAvg) / 2;
}

export interface HistoricalAverageBaseline {
  averages: Map<string, number>;
  featureNames: string[];
  keyIndices: number[];
}

export function trainHistoricalAverage(
  X: number[][],
  y: number[],
  keyIndices: number[],
  featureNames: string[]
): HistoricalAverageBaseline {
  const averages = new Map<string, number>();
  const counts = new Map<string, number>();

  for (let i = 0; i < X.length; i++) {
    const key = keyIndices.map((idx) => X[i][idx]).join(':');
    if (!averages.has(key)) {
      averages.set(key, 0);
      counts.set(key, 0);
    }
    averages.set(key, averages.get(key)! + y[i]);
    counts.set(key, counts.get(key)! + 1);
  }

  for (const [key, val] of averages) {
    averages.set(key, val / counts.get(key)!);
  }

  return { averages, featureNames, keyIndices };
}

export function predictHistoricalAverage(model: HistoricalAverageBaseline, x: number[]): number {
  const key = model.keyIndices.map((idx) => x[idx]).join(':');
  return model.averages.get(key) ?? 0;
}
