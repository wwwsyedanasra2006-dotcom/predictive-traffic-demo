import { mean } from './stats';

export interface LinearRegressionModel {
  weights: number[];
  bias: number;
  featureNames: string[];
  featureMeans: number[];
  featureStds: number[];
}

export function trainLinearRegression(
  X: number[][],
  y: number[],
  featureNames: string[],
  featureMeans: number[],
  featureStds: number[],
  epochs: number = 300,
  lr: number = 0.01
): LinearRegressionModel {
  const n = X.length;
  const d = X[0].length;
  const weights = new Array(d).fill(0);
  let bias = 0;

  for (let epoch = 0; epoch < epochs; epoch++) {
    const grads = new Array(d).fill(0);
    let gradBias = 0;
    for (let i = 0; i < n; i++) {
      let pred = bias;
      for (let j = 0; j < d; j++) pred += weights[j] * X[i][j];
      const error = pred - y[i];
      for (let j = 0; j < d; j++) grads[j] += error * X[i][j];
      gradBias += error;
    }
    for (let j = 0; j < d; j++) weights[j] -= (lr * grads[j]) / n;
    bias -= (lr * gradBias) / n;
  }

  return { weights, bias, featureNames, featureMeans, featureStds };
}

export function predictLinear(model: LinearRegressionModel, x: number[]): number {
  let pred = model.bias;
  for (let j = 0; j < model.weights.length; j++) pred += model.weights[j] * x[j];
  return pred;
}

export function linearFeatureImportance(model: LinearRegressionModel): { feature: string; importance: number }[] {
  return model.featureNames.map((name, i) => ({
    feature: name,
    importance: Math.abs(model.weights[i] * model.featureStds[i]),
  })).sort((a, b) => b.importance - a.importance);
}

export function scaleFeatures(X: number[][], means: number[], stds: number[]): number[][] {
  return X.map((row) => row.map((v, i) => (v - means[i]) / (stds[i] || 1)));
}

export function computeFeatureStats(X: number[][]): { means: number[]; stds: number[] } {
  const d = X[0].length;
  const means: number[] = [];
  const stds: number[] = [];
  for (let j = 0; j < d; j++) {
    const col = X.map((r) => r[j]);
    means.push(mean(col));
    const m = means[j];
    const variance = col.reduce((s, v) => s + (v - m) ** 2, 0) / col.length;
    stds.push(Math.sqrt(variance) || 1);
  }
  return { means, stds };
}
