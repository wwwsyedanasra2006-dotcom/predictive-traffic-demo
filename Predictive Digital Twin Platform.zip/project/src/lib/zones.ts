import type { Zone, ZoneType } from './types';

export const ZONES: Zone[] = [
  { id: 'z1', name: 'Downtown', type: 'commercial', population: 45000, area: 12, roadCapacity: 2000, powerSupply: 45, waterSupply: 30 },
  { id: 'z2', name: 'Midtown', type: 'commercial', population: 38000, area: 10, roadCapacity: 1800, powerSupply: 38, waterSupply: 26 },
  { id: 'z3', name: 'Riverside', type: 'residential', population: 52000, area: 18, roadCapacity: 1500, powerSupply: 35, waterSupply: 34 },
  { id: 'z4', name: 'Highland Park', type: 'residential', population: 30000, area: 15, roadCapacity: 1200, powerSupply: 28, waterSupply: 22 },
  { id: 'z5', name: 'Industrial Bay', type: 'industrial', population: 8000, area: 25, roadCapacity: 1000, powerSupply: 60, waterSupply: 40 },
  { id: 'z6', name: 'Port District', type: 'industrial', population: 6000, area: 20, roadCapacity: 1100, powerSupply: 55, waterSupply: 35 },
  { id: 'z7', name: 'Transit Hub', type: 'transport', population: 12000, area: 8, roadCapacity: 3000, powerSupply: 30, waterSupply: 18 },
  { id: 'z8', name: 'Airport Zone', type: 'transport', population: 5000, area: 22, roadCapacity: 2500, powerSupply: 40, waterSupply: 20 },
];

export const ZONE_NAMES: Record<string, string> = Object.fromEntries(
  ZONES.map((z) => [z.id, z.name])
);

export const ZONE_TYPE_COLORS: Record<ZoneType, string> = {
  residential: '#10b981',
  commercial: '#3b82f6',
  industrial: '#f59e0b',
  transport: '#8b5cf6',
};

export function zoneTypeLabel(t: ZoneType): string {
  return t.charAt(0).toUpperCase() + t.slice(1);
}
