import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface SimulationHistoryRecord {
  id: string;
  name: string;
  module: string;
  scenario_params: Record<string, unknown>;
  baseline_results: Record<string, unknown>;
  modified_results: Record<string, unknown>;
  risk_alerts: Record<string, unknown>[];
  optimization_result: Record<string, unknown> | null;
  notes: string;
  created_at: string;
}

export async function saveSimulation(
  data: Omit<SimulationHistoryRecord, 'id' | 'created_at'>
): Promise<SimulationHistoryRecord | null> {
  const { data: result, error } = await supabase
    .from('simulation_history')
    .insert(data)
    .select()
    .maybeSingle();

  if (error) {
    console.error('Failed to save simulation:', error);
    return null;
  }
  return result as SimulationHistoryRecord | null;
}

export async function listSimulations(): Promise<SimulationHistoryRecord[]> {
  const { data, error } = await supabase
    .from('simulation_history')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    console.error('Failed to list simulations:', error);
    return [];
  }
  return (data || []) as SimulationHistoryRecord[];
}

export async function getSimulation(id: string): Promise<SimulationHistoryRecord | null> {
  const { data, error } = await supabase
    .from('simulation_history')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    console.error('Failed to get simulation:', error);
    return null;
  }
  return data as SimulationHistoryRecord | null;
}

export async function deleteSimulation(id: string): Promise<boolean> {
  const { error } = await supabase
    .from('simulation_history')
    .delete()
    .eq('id', id);

  if (error) {
    console.error('Failed to delete simulation:', error);
    return false;
  }
  return true;
}
