import { generateTrafficDataset, generateEnergyDataset, generateWaterDataset } from './dataGenerator';
import { ZONES } from './zones';
import {
  chronologicalSplit,
  mae,
  rmse,
  r2Score,
} from './ml/stats';
import {
  computeFeatureStats,
  scaleFeatures,
  trainLinearRegression,
  predictLinear,
  linearFeatureImportance,
  type LinearRegressionModel,
} from './ml/linearRegression';
import {
  trainRandomForest,
  predictRandomForest,
  randomForestFeatureImportance,
  type RandomForestModel,
} from './ml/randomForest';
import {
  trainHistoricalAverage,
  predictHistoricalAverage,
  type HistoricalAverageBaseline,
} from './ml/baseline';
import type {
  TrafficRecord,
  EnergyRecord,
  WaterRecord,
  CongestionPrediction,
  EnergyPrediction,
  WaterPrediction,
  ModelMetrics,
  ScenarioParams,
  WeatherCondition,
} from './types';

const WEATHER_MAP: Record<WeatherCondition, number> = {
  clear: 0,
  cloudy: 1,
  rain: 2,
  storm: 3,
  heatwave: 4,
};

const ZONE_TYPE_MAP: Record<string, number> = {
  residential: 0,
  commercial: 1,
  industrial: 2,
  transport: 3,
};

function trafficFeatures(r: TrafficRecord): number[] {
  return [
    r.hour,
    r.dayOfWeek,
    r.vehicleCount,
    r.avgSpeed,
    r.roadCapacity,
    WEATHER_MAP[r.weather],
    ZONE_TYPE_MAP[r.zoneType],
    r.vehicleCount / r.roadCapacity,
  ];
}

const TRAFFIC_FEATURE_NAMES = [
  'hour', 'dayOfWeek', 'vehicleCount', 'avgSpeed', 'roadCapacity', 'weather', 'zoneType', 'densityRatio',
];

function energyFeatures(r: EnergyRecord): number[] {
  return [
    r.hour,
    r.dayOfWeek,
    r.temperature,
    r.historicalDemand,
    ZONE_TYPE_MAP[r.zoneType],
    r.supply,
  ];
}

const ENERGY_FEATURE_NAMES = [
  'hour', 'dayOfWeek', 'temperature', 'historicalDemand', 'zoneType', 'supply',
];

function waterFeatures(r: WaterRecord): number[] {
  return [
    r.hour,
    r.dayOfWeek,
    r.temperature,
    r.population,
    WEATHER_MAP[r.weather],
    r.reservoirLevel,
    r.supply,
    ZONE_TYPE_MAP[r.zoneType],
  ];
}

const WATER_FEATURE_NAMES = [
  'hour', 'dayOfWeek', 'temperature', 'population', 'weather', 'reservoirLevel', 'supply', 'zoneType',
];

export interface TrainedModels {
  traffic: {
    rf: RandomForestModel;
    baseline: HistoricalAverageBaseline;
    records: TrafficRecord[];
  };
  energy: {
    rf: RandomForestModel;
    baseline: HistoricalAverageBaseline;
    records: EnergyRecord[];
  };
  water: {
    rf: RandomForestModel;
    baseline: HistoricalAverageBaseline;
    records: WaterRecord[];
  };
}

let cachedModels: TrainedModels | null = null;

export function getTrainedModels(): TrainedModels {
  if (cachedModels) return cachedModels;

  const trafficRecords = generateTrafficDataset(21);
  const energyRecords = generateEnergyDataset(21);
  const waterRecords = generateWaterDataset(21);

  const trafficX = trafficRecords.map(trafficFeatures);
  const trafficY = trafficRecords.map((r) => r.congestion);
  const { means: tMeans, stds: tStds } = computeFeatureStats(trafficX);
  const trafficXScaled = scaleFeatures(trafficX, tMeans, tStds);
  const trafficRF = trainRandomForest(trafficXScaled, trafficY, TRAFFIC_FEATURE_NAMES, tMeans, tStds, 15, 7, 42);
  const trafficBaseline = trainHistoricalAverage(trafficX, trafficY, [1, 6], TRAFFIC_FEATURE_NAMES);

  const energyX = energyRecords.map(energyFeatures);
  const energyY = energyRecords.map((r) => r.demand);
  const { means: eMeans, stds: eStds } = computeFeatureStats(energyX);
  const energyXScaled = scaleFeatures(energyX, eMeans, eStds);
  const energyRF = trainRandomForest(energyXScaled, energyY, ENERGY_FEATURE_NAMES, eMeans, eStds, 15, 7, 43);
  const energyBaseline = trainHistoricalAverage(energyX, energyY, [1, 4], ENERGY_FEATURE_NAMES);

  const waterX = waterRecords.map(waterFeatures);
  const waterY = waterRecords.map((r) => r.demand);
  const { means: wMeans, stds: wStds } = computeFeatureStats(waterX);
  const waterXScaled = scaleFeatures(waterX, wMeans, wStds);
  const waterRF = trainRandomForest(waterXScaled, waterY, WATER_FEATURE_NAMES, wMeans, wStds, 15, 7, 44);
  const waterBaseline = trainHistoricalAverage(waterX, waterY, [1, 7], WATER_FEATURE_NAMES);

  cachedModels = {
    traffic: { rf: trafficRF, baseline: trafficBaseline, records: trafficRecords },
    energy: { rf: energyRF, baseline: energyBaseline, records: energyRecords },
    water: { rf: waterRF, baseline: waterBaseline, records: waterRecords },
  };
  return cachedModels;
}

export function predictTraffic(params: ScenarioParams, hoursAhead: number = 12): CongestionPrediction[] {
  const models = getTrainedModels();
  const results: CongestionPrediction[] = [];

  for (const zone of ZONES) {
    const lastRecord = [...models.traffic.records]
      .filter((r) => r.zoneId === zone.id)
      .sort((a, b) => b.timestamp - a.timestamp)[0];

    const currentHour = lastRecord ? lastRecord.hour : 8;
    const dayOfWeek = lastRecord ? lastRecord.dayOfWeek : 2;

    const forecast: { hour: number; value: number }[] = [];
    const modifiedVehicle = params.trafficMultiplier;
    const finalAvgSpeed = params.signalOptimization ? lastRecord.avgSpeed * 1.15 : lastRecord.avgSpeed;

    for (let h = 1; h <= hoursAhead; h++) {
      const hour = (currentHour + h) % 24;
      const dw = (dayOfWeek + Math.floor((currentHour + h) / 24)) % 7;

      let vehicleCount = lastRecord.vehicleCount * (1 + Math.sin(h / 3) * 0.15);
      vehicleCount *= params.trafficMultiplier;
      if (params.weatherScenario === 'storm') vehicleCount *= 0.75;
      if (params.weatherScenario === 'rain') vehicleCount *= 0.88;
      if (params.weatherScenario === 'heatwave') vehicleCount *= 1.05;

      let avgSpeed = lastRecord.avgSpeed;
      if (params.signalOptimization) avgSpeed *= 1.15;

      const weatherNum = WEATHER_MAP[params.weatherScenario];
      const features = [
        hour, dw, Math.round(vehicleCount), Math.round(avgSpeed * 10) / 10,
        zone.roadCapacity, weatherNum, ZONE_TYPE_MAP[zone.type],
        vehicleCount / zone.roadCapacity,
      ];
      const scaled = features.map((v, i) => (v - models.traffic.rf.featureMeans[i]) / (models.traffic.rf.featureStds[i] || 1));
      const pred = predictRandomForest(models.traffic.rf, scaled);
      const clamped = Math.max(0, Math.min(1, pred));
      forecast.push({ hour, value: Math.round(clamped * 1000) / 1000 });
    }

    const currentCongestion = lastRecord.congestion;
    const predictedCongestion = forecast.reduce((a, b) => a + b.value, 0) / forecast.length;
    const riskScore = predictedCongestion;

    results.push({
      zoneId: zone.id,
      zoneName: zone.name,
      currentCongestion: Math.round(currentCongestion * 1000) / 1000,
      predictedCongestion: Math.round(predictedCongestion * 1000) / 1000,
      forecast,
      riskLevel: riskScore > 0.7 ? 'critical' : riskScore > 0.5 ? 'high' : riskScore > 0.3 ? 'medium' : 'low',
      modelUsed: 'Random Forest (15 trees, depth 7)',
      features: {
        vehicleCount: Math.round(lastRecord.vehicleCount * modifiedVehicle),
        avgSpeed: Math.round(finalAvgSpeed * 10) / 10,
        roadCapacity: zone.roadCapacity,
        densityRatio: Math.round((lastRecord.vehicleCount * modifiedVehicle / zone.roadCapacity) * 1000) / 1000,
      },
    });
  }

  return results;
}

export function predictEnergy(params: ScenarioParams, hoursAhead: number = 12): EnergyPrediction[] {
  const models = getTrainedModels();
  const results: EnergyPrediction[] = [];

  for (const zone of ZONES) {
    const lastRecord = [...models.energy.records]
      .filter((r) => r.zoneId === zone.id)
      .sort((a, b) => b.timestamp - a.timestamp)[0];

    const currentHour = lastRecord ? lastRecord.hour : 8;
    const dayOfWeek = lastRecord ? lastRecord.dayOfWeek : 2;

    const forecast: { hour: number; demand: number; supply: number }[] = [];

    for (let h = 1; h <= hoursAhead; h++) {
      const hour = (currentHour + h) % 24;
      const dw = (dayOfWeek + Math.floor((currentHour + h) / 24)) % 7;
      const temp = lastRecord.temperature + params.temperatureOffset;
      let supply = zone.powerSupply * (1 + params.energySupplyChange / 100 - params.loadShedding / 100);

      const features = [
        hour, dw, Math.round(temp * 10) / 10, lastRecord.historicalDemand,
        ZONE_TYPE_MAP[zone.type], Math.round(supply * 100) / 100,
      ];
      const scaled = features.map((v, i) => (v - models.energy.rf.featureMeans[i]) / (models.energy.rf.featureStds[i] || 1));
      const pred = predictRandomForest(models.energy.rf, scaled);
      const demand = Math.max(0, pred);
      forecast.push({ hour, demand: Math.round(demand * 100) / 100, supply: Math.round(supply * 100) / 100 });
    }

    const currentDemand = lastRecord.demand;
    const predictedDemand = forecast.reduce((a, b) => a + b.demand, 0) / forecast.length;
    const avgSupply = forecast.reduce((a, b) => a + b.supply, 0) / forecast.length;
    const supplyGap = predictedDemand - avgSupply;
    const riskScore = supplyGap > 0 ? supplyGap / avgSupply : 0;

    results.push({
      zoneId: zone.id,
      zoneName: zone.name,
      currentDemand: Math.round(currentDemand * 100) / 100,
      predictedDemand: Math.round(predictedDemand * 100) / 100,
      supply: Math.round(avgSupply * 100) / 100,
      supplyGap: Math.round(supplyGap * 100) / 100,
      forecast,
      riskLevel: riskScore > 0.3 ? 'critical' : riskScore > 0.15 ? 'high' : riskScore > 0.05 ? 'medium' : 'low',
      modelUsed: 'Random Forest (15 trees, depth 7)',
      features: {
        temperature: Math.round((lastRecord.temperature + params.temperatureOffset) * 10) / 10,
        historicalDemand: lastRecord.historicalDemand,
        supply: Math.round(avgSupply * 100) / 100,
      },
    });
  }

  return results;
}

export function predictWater(params: ScenarioParams, hoursAhead: number = 12): WaterPrediction[] {
  const models = getTrainedModels();
  const results: WaterPrediction[] = [];

  for (const zone of ZONES) {
    const lastRecord = [...models.water.records]
      .filter((r) => r.zoneId === zone.id)
      .sort((a, b) => b.timestamp - a.timestamp)[0];

    const currentHour = lastRecord ? lastRecord.hour : 8;
    const dayOfWeek = lastRecord ? lastRecord.dayOfWeek : 2;

    const forecast: { hour: number; demand: number; supply: number }[] = [];

    for (let h = 1; h <= hoursAhead; h++) {
      const hour = (currentHour + h) % 24;
      const dw = (dayOfWeek + Math.floor((currentHour + h) / 24)) % 7;
      const temp = lastRecord.temperature + params.temperatureOffset;
      let supply = zone.waterSupply;
      if (params.waterConservation) supply *= 0.9;

      const features = [
        hour, dw, Math.round(temp * 10) / 10, zone.population,
        WEATHER_MAP[params.weatherScenario], lastRecord.reservoirLevel,
        Math.round(supply * 100) / 100, ZONE_TYPE_MAP[zone.type],
      ];
      const scaled = features.map((v, i) => (v - models.water.rf.featureMeans[i]) / (models.water.rf.featureStds[i] || 1));
      const pred = predictRandomForest(models.water.rf, scaled);
      let demand = Math.max(0, pred);
      demand *= (1 + params.waterDemandChange / 100);
      if (params.weatherScenario === 'heatwave') demand *= 1.25;

      forecast.push({ hour, demand: Math.round(demand * 100) / 100, supply: Math.round(supply * 100) / 100 });
    }

    const currentDemand = lastRecord.demand;
    const predictedDemand = forecast.reduce((a, b) => a + b.demand, 0) / forecast.length;
    const avgSupply = forecast.reduce((a, b) => a + b.supply, 0) / forecast.length;
    const supplyGap = predictedDemand - avgSupply;
    const riskScore = supplyGap > 0 ? supplyGap / avgSupply : 0;

    results.push({
      zoneId: zone.id,
      zoneName: zone.name,
      currentDemand: Math.round(currentDemand * 100) / 100,
      predictedDemand: Math.round(predictedDemand * 100) / 100,
      supply: Math.round(avgSupply * 100) / 100,
      supplyGap: Math.round(supplyGap * 100) / 100,
      forecast,
      riskLevel: riskScore > 0.3 ? 'critical' : riskScore > 0.15 ? 'high' : riskScore > 0.05 ? 'medium' : 'low',
      modelUsed: 'Random Forest (15 trees, depth 7)',
      features: {
        temperature: Math.round((lastRecord.temperature + params.temperatureOffset) * 10) / 10,
        population: zone.population,
        reservoirLevel: lastRecord.reservoirLevel,
        supply: Math.round(avgSupply * 100) / 100,
      },
    });
  }

  return results;
}

export function evaluateTrafficModel(): ModelMetrics {
  const models = getTrainedModels();
  const X = models.traffic.records.map(trafficFeatures);
  const y = models.traffic.records.map((r) => r.congestion);
  const split = chronologicalSplit(X, y, 0.2);

  const xTrainScaled = split.xTrain.map((row) => row.map((v, i) => (v - models.traffic.rf.featureMeans[i]) / (models.traffic.rf.featureStds[i] || 1)));
  const xTestScaled = split.xTest.map((row) => row.map((v, i) => (v - models.traffic.rf.featureMeans[i]) / (models.traffic.rf.featureStds[i] || 1)));

  const rfPred = split.yTest.map((_, i) => {
    const p = predictRandomForest(models.traffic.rf, xTestScaled[i]);
    return Math.max(0, Math.min(1, p));
  });
  const baselinePred = split.xTest.map((x) => predictHistoricalAverage(models.traffic.baseline, x));

  const avp: { actual: number; predicted: number; baseline: number }[] = [];
  for (let i = 0; i < split.yTest.length; i++) {
    avp.push({
      actual: Math.round(split.yTest[i] * 1000) / 1000,
      predicted: Math.round(rfPred[i] * 1000) / 1000,
      baseline: Math.round(baselinePred[i] * 1000) / 1000,
    });
  }

  return {
    mae: Math.round(mae(split.yTest, rfPred) * 10000) / 10000,
    rmse: Math.round(rmse(split.yTest, rfPred) * 10000) / 10000,
    r2: Math.round(r2Score(split.yTest, rfPred) * 10000) / 10000,
    baselineMae: Math.round(mae(split.yTest, baselinePred) * 10000) / 10000,
    baselineRmse: Math.round(rmse(split.yTest, baselinePred) * 10000) / 10000,
    baselineR2: Math.round(r2Score(split.yTest, baselinePred) * 10000) / 10000,
    trainSize: split.xTrain.length,
    testSize: split.xTest.length,
    featureNames: TRAFFIC_FEATURE_NAMES,
    featureImportance: randomForestFeatureImportance(models.traffic.rf),
    actualVsPredicted: avp.slice(0, 60),
    modelName: 'Random Forest (15 trees, max depth 7)',
    baselineName: 'Historical Average by zone+weather',
  };
}

export function evaluateEnergyModel(): ModelMetrics {
  const models = getTrainedModels();
  const X = models.energy.records.map(energyFeatures);
  const y = models.energy.records.map((r) => r.demand);
  const split = chronologicalSplit(X, y, 0.2);

  const xTestScaled = split.xTest.map((row) => row.map((v, i) => (v - models.energy.rf.featureMeans[i]) / (models.energy.rf.featureStds[i] || 1)));
  const rfPred = split.yTest.map((_, i) => predictRandomForest(models.energy.rf, xTestScaled[i]));
  const baselinePred = split.xTest.map((x) => predictHistoricalAverage(models.energy.baseline, x));

  const avp: { actual: number; predicted: number; baseline: number }[] = [];
  for (let i = 0; i < split.yTest.length; i++) {
    avp.push({
      actual: Math.round(split.yTest[i] * 100) / 100,
      predicted: Math.round(rfPred[i] * 100) / 100,
      baseline: Math.round(baselinePred[i] * 100) / 100,
    });
  }

  return {
    mae: Math.round(mae(split.yTest, rfPred) * 100) / 100,
    rmse: Math.round(rmse(split.yTest, rfPred) * 100) / 100,
    r2: Math.round(r2Score(split.yTest, rfPred) * 10000) / 10000,
    baselineMae: Math.round(mae(split.yTest, baselinePred) * 100) / 100,
    baselineRmse: Math.round(rmse(split.yTest, baselinePred) * 100) / 100,
    baselineR2: Math.round(r2Score(split.yTest, baselinePred) * 10000) / 10000,
    trainSize: split.xTrain.length,
    testSize: split.xTest.length,
    featureNames: ENERGY_FEATURE_NAMES,
    featureImportance: randomForestFeatureImportance(models.energy.rf),
    actualVsPredicted: avp.slice(0, 60),
    modelName: 'Random Forest (15 trees, max depth 7)',
    baselineName: 'Historical Average by zone+supply',
  };
}

export function evaluateWaterModel(): ModelMetrics {
  const models = getTrainedModels();
  const X = models.water.records.map(waterFeatures);
  const y = models.water.records.map((r) => r.demand);
  const split = chronologicalSplit(X, y, 0.2);

  const xTestScaled = split.xTest.map((row) => row.map((v, i) => (v - models.water.rf.featureMeans[i]) / (models.water.rf.featureStds[i] || 1)));
  const rfPred = split.yTest.map((_, i) => predictRandomForest(models.water.rf, xTestScaled[i]));
  const baselinePred = split.xTest.map((x) => predictHistoricalAverage(models.water.baseline, x));

  const avp: { actual: number; predicted: number; baseline: number }[] = [];
  for (let i = 0; i < split.yTest.length; i++) {
    avp.push({
      actual: Math.round(split.yTest[i] * 100) / 100,
      predicted: Math.round(rfPred[i] * 100) / 100,
      baseline: Math.round(baselinePred[i] * 100) / 100,
    });
  }

  return {
    mae: Math.round(mae(split.yTest, rfPred) * 100) / 100,
    rmse: Math.round(rmse(split.yTest, rfPred) * 100) / 100,
    r2: Math.round(r2Score(split.yTest, rfPred) * 10000) / 10000,
    baselineMae: Math.round(mae(split.yTest, baselinePred) * 100) / 100,
    baselineRmse: Math.round(rmse(split.yTest, baselinePred) * 100) / 100,
    baselineR2: Math.round(r2Score(split.yTest, baselinePred) * 10000) / 10000,
    trainSize: split.xTrain.length,
    testSize: split.xTest.length,
    featureNames: WATER_FEATURE_NAMES,
    featureImportance: randomForestFeatureImportance(models.water.rf),
    actualVsPredicted: avp.slice(0, 60),
    modelName: 'Random Forest (15 trees, max depth 7)',
    baselineName: 'Historical Average by zone+zoneType',
  };
}
