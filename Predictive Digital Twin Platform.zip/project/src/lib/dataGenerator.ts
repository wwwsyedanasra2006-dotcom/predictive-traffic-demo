import { ZONES } from './zones';
import type { TrafficRecord, EnergyRecord, WaterRecord, WeatherCondition, ZoneType } from './types';

const SEED = 42;

function mulberry32(seed: number) {
  let a = seed;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const rng = mulberry32(SEED);

function gauss(mean: number, std: number): number {
  const u1 = rng() || 0.0001;
  const u2 = rng();
  return mean + std * Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

const WEATHERS: WeatherCondition[] = ['clear', 'cloudy', 'rain', 'storm', 'heatwave'];

function pickWeather(hour: number, dayOfWeek: number, tempBias: number): WeatherCondition {
  const r = rng();
  if (tempBias > 35 && r < 0.3) return 'heatwave';
  if (r < 0.5) return 'clear';
  if (r < 0.75) return 'cloudy';
  if (r < 0.9) return 'rain';
  if (r < 0.96) return 'storm';
  return 'heatwave';
}

function tempForHour(hour: number, baseTemp: number): number {
  const seasonal = 20 + 10 * Math.sin((hour - 6) / 24 * 2 * Math.PI);
  return Math.max(0, seasonal + baseTemp + gauss(0, 3));
}

function trafficVolume(zoneType: ZoneType, hour: number, dayOfWeek: number, weather: WeatherCondition, roadCap: number): number {
  let base: number;
  const isWeekend = dayOfWeek >= 5;
  switch (zoneType) {
    case 'commercial':
      base = roadCap * 0.65;
      if (hour >= 7 && hour <= 9) base *= 1.6;
      else if (hour >= 17 && hour <= 19) base *= 1.7;
      else if (hour >= 22 || hour <= 5) base *= 0.2;
      break;
    case 'residential':
      base = roadCap * 0.4;
      if (hour >= 7 && hour <= 9) base *= 1.5;
      else if (hour >= 17 && hour <= 19) base *= 1.3;
      else if (hour >= 22 || hour <= 5) base *= 0.15;
      break;
    case 'industrial':
      base = roadCap * 0.5;
      if (hour >= 6 && hour <= 16) base *= 1.3;
      else if (hour >= 22 || hour <= 4) base *= 0.25;
      break;
    case 'transport':
      base = roadCap * 0.55;
      if (hour >= 6 && hour <= 20) base *= 1.4;
      else base *= 0.5;
      break;
  }
  if (isWeekend) base *= 0.7;
  if (weather === 'rain') base *= 0.85;
  if (weather === 'storm') base *= 0.7;
  if (weather === 'heatwave') base *= 1.05;
  return Math.max(10, base + gauss(0, base * 0.1));
}

function congestionLevel(vehicleCount: number, avgSpeed: number, roadCap: number): number {
  const densityRatio = vehicleCount / roadCap;
  const speedRatio = avgSpeed / 60;
  const raw = densityRatio * 0.6 + (1 - speedRatio) * 0.4;
  return Math.max(0, Math.min(1, raw));
}

function avgSpeedForTraffic(vehicleCount: number, roadCap: number): number {
  const ratio = vehicleCount / roadCap;
  if (ratio > 1) return gauss(15, 5);
  const speed = 60 * (1 - ratio * 0.7);
  return Math.max(10, Math.min(65, speed + gauss(0, 4)));
}

function energyDemand(zoneType: ZoneType, hour: number, dayOfWeek: number, temperature: number, pop: number, supply: number): number {
  let base: number;
  switch (zoneType) {
    case 'residential':
      base = pop * 0.0008;
      if (hour >= 18 && hour <= 22) base *= 2.5;
      else if (hour >= 6 && hour <= 9) base *= 1.8;
      else if (hour >= 0 && hour <= 5) base *= 0.5;
      break;
    case 'commercial':
      base = pop * 0.0012;
      if (hour >= 9 && hour <= 18) base *= 2.2;
      else if (hour >= 0 && hour <= 5) base *= 0.3;
      break;
    case 'industrial':
      base = pop * 0.003;
      if (hour >= 6 && hour <= 20) base *= 1.8;
      else base *= 0.6;
      break;
    case 'transport':
      base = pop * 0.0015;
      if (hour >= 6 && hour <= 22) base *= 1.5;
      else base *= 0.4;
      break;
  }
  if (temperature > 30) base *= 1 + (temperature - 30) * 0.04;
  else if (temperature < 10) base *= 1 + (10 - temperature) * 0.03;
  if (dayOfWeek >= 5 && zoneType !== 'residential') base *= 0.6;
  return Math.max(1, base + gauss(0, base * 0.08));
}

function waterDemand(zoneType: ZoneType, hour: number, dayOfWeek: number, temperature: number, pop: number, weather: WeatherCondition): number {
  let base: number;
  switch (zoneType) {
    case 'residential':
      base = pop * 0.00012;
      if (hour >= 6 && hour <= 9) base *= 2.0;
      else if (hour >= 18 && hour <= 21) base *= 2.5;
      else if (hour >= 0 && hour <= 5) base *= 0.3;
      break;
    case 'commercial':
      base = pop * 0.0001;
      if (hour >= 9 && hour <= 18) base *= 2.5;
      else base *= 0.4;
      break;
    case 'industrial':
      base = pop * 0.0008;
      if (hour >= 6 && hour <= 20) base *= 1.8;
      else base *= 0.5;
      break;
    case 'transport':
      base = pop * 0.00006;
      if (hour >= 6 && hour <= 22) base *= 1.5;
      else base *= 0.3;
      break;
  }
  if (temperature > 30) base *= 1 + (temperature - 30) * 0.05;
  if (weather === 'heatwave') base *= 1.3;
  if (dayOfWeek >= 5 && zoneType === 'residential') base *= 1.15;
  return Math.max(0.5, base + gauss(0, base * 0.07));
}

export function generateTrafficDataset(days: number = 30): TrafficRecord[] {
  const records: TrafficRecord[] = [];
  const hoursPerDay = 24;
  let ts = 0;
  for (let day = 0; day < days; day++) {
    const dayOfWeek = day % 7;
    for (let hour = 0; hour < hoursPerDay; hour++) {
      for (const zone of ZONES) {
        const temp = tempForHour(hour, (day % 30) * 0.3);
        const weather = pickWeather(hour, dayOfWeek, temp);
        const vc = trafficVolume(zone.type, hour, dayOfWeek, weather, zone.roadCapacity);
        const speed = avgSpeedForTraffic(vc, zone.roadCapacity);
        const cong = congestionLevel(vc, speed, zone.roadCapacity);
        records.push({
          timestamp: ts,
          zoneId: zone.id,
          zoneType: zone.type,
          vehicleCount: Math.round(vc),
          avgSpeed: Math.round(speed * 10) / 10,
          roadCapacity: zone.roadCapacity,
          weather,
          dayOfWeek,
          hour,
          congestion: Math.round(cong * 1000) / 1000,
        });
      }
    }
    ts += hoursPerDay;
  }
  return records;
}

export function generateEnergyDataset(days: number = 30): EnergyRecord[] {
  const records: EnergyRecord[] = [];
  let ts = 0;
  for (let day = 0; day < days; day++) {
    const dayOfWeek = day % 7;
    for (let hour = 0; hour < 24; hour++) {
      for (const zone of ZONES) {
        const temp = tempForHour(hour, (day % 30) * 0.3);
        const demand = energyDemand(zone.type, hour, dayOfWeek, temp, zone.population, zone.powerSupply);
        const histDemand = demand * (0.9 + rng() * 0.2);
        records.push({
          timestamp: ts,
          zoneId: zone.id,
          zoneType: zone.type,
          hour,
          dayOfWeek,
          temperature: Math.round(temp * 10) / 10,
          historicalDemand: Math.round(histDemand * 100) / 100,
          supply: zone.powerSupply,
          demand: Math.round(demand * 100) / 100,
        });
      }
    }
    ts += 24;
  }
  return records;
}

export function generateWaterDataset(days: number = 30): WaterRecord[] {
  const records: WaterRecord[] = [];
  let ts = 0;
  for (let day = 0; day < days; day++) {
    const dayOfWeek = day % 7;
    for (let hour = 0; hour < 24; hour++) {
      for (const zone of ZONES) {
        const temp = tempForHour(hour, (day % 30) * 0.3);
        const weather = pickWeather(hour, dayOfWeek, temp);
        const demand = waterDemand(zone.type, hour, dayOfWeek, temp, zone.population, weather);
        const reservoirStart = zone.waterSupply * (0.7 + rng() * 0.3);
        records.push({
          timestamp: ts,
          zoneId: zone.id,
          zoneType: zone.type,
          hour,
          dayOfWeek,
          temperature: Math.round(temp * 10) / 10,
          population: zone.population,
          weather,
          reservoirLevel: Math.round(reservoirStart * 100) / 100,
          supply: zone.waterSupply,
          demand: Math.round(demand * 100) / 100,
        });
      }
    }
    ts += 24;
  }
  return records;
}
