import { ZONES } from './zones';
import type { OptimizationResult } from './types';

function zonePriority(type: string): number {
  switch (type) {
    case 'residential': return 3;
    case 'commercial': return 2;
    case 'industrial': return 1;
    case 'transport': return 2;
    default: return 1;
  }
}

export function optimizeEnergyAllocation(
  demands: { zoneId: string; demand: number }[],
  totalSupply: number
): OptimizationResult {
  const zonesWithPriority = demands.map((d) => {
    const zone = ZONES.find((z) => z.id === d.zoneId);
    return {
      zoneId: d.zoneId,
      zoneName: zone?.name || d.zoneId,
      demand: d.demand,
      priority: zonePriority(zone?.type || 'residential'),
    };
  });

  const sortedByPriority = [...zonesWithPriority].sort((a, b) => b.priority - a.priority);

  let remaining = totalSupply;
  const allocation: { zoneId: string; zoneName: string; demand: number; allocated: number; unmet: number; priority: number }[] = [];
  const perZoneShare = totalSupply / sortedByPriority.length;
  const perZoneCap = perZoneShare * 1.5;

  for (const z of sortedByPriority) {
    const allocated = Math.min(z.demand, Math.min(remaining, perZoneCap));
    remaining -= allocated;
    allocation.push({
      zoneId: z.zoneId,
      zoneName: z.zoneName,
      demand: Math.round(z.demand * 100) / 100,
      allocated: Math.round(allocated * 100) / 100,
      unmet: Math.round((z.demand - allocated) * 100) / 100,
      priority: z.priority,
    });
  }

  if (remaining > 0) {
    for (const a of allocation) {
      if (remaining <= 0) break;
      if (a.unmet > 0) {
        const extra = Math.min(a.unmet, remaining);
        a.allocated = Math.round((a.allocated + extra) * 100) / 100;
        a.unmet = Math.round((a.unmet - extra) * 100) / 100;
        remaining -= extra;
      }
    }
  }

  const totalDemand = zonesWithPriority.reduce((s, z) => s + z.demand, 0);
  const totalAllocated = allocation.reduce((s, a) => s + a.allocated, 0);
  const totalUnmet = allocation.reduce((s, a) => s + a.unmet, 0);
  const baselineUnmet = Math.max(0, totalDemand - totalSupply);

  const objectiveValue = Math.round((totalAllocated / totalDemand) * 10000) / 10000;

  const explanationParts: string[] = [];
  explanationParts.push(`Objective: maximize fulfilled demand weighted by zone priority (residential > commercial/transport > industrial).`);
  explanationParts.push(`Total supply: ${Math.round(totalSupply * 100) / 100} MW. Total demand: ${Math.round(totalDemand * 100) / 100} MW.`);
  explanationParts.push(`Greedy allocation: each zone receives up to ${Math.round(perZoneCap * 100) / 100} MW (1.5× per-zone share) in priority order, then surplus redistributes to zones with unmet demand.`);
  if (totalUnmet > 0) {
    const unmetZones = allocation.filter((a) => a.unmet > 0).map((a) => `${a.zoneName} (${a.unmet.toFixed(2)} MW)`);
    explanationParts.push(`Unmet demand remains in: ${unmetZones.join(', ')}.`);
  } else {
    explanationParts.push(`All demand fully met — no unmet demand.`);
  }

  return {
    module: 'energy',
    totalResource: Math.round(totalSupply * 100) / 100,
    totalDemand: Math.round(totalDemand * 100) / 100,
    allocation: allocation.sort((a, b) => b.priority - a.priority),
    objectiveValue,
    totalUnmet: Math.round(totalUnmet * 100) / 100,
    explanation: explanationParts.join(' '),
    baselineUnmet: Math.round(baselineUnmet * 100) / 100,
    optimizedUnmet: Math.round(totalUnmet * 100) / 100,
    improvement: Math.round((baselineUnmet - totalUnmet) * 100) / 100,
  };
}

export function optimizeWaterAllocation(
  demands: { zoneId: string; demand: number }[],
  totalSupply: number
): OptimizationResult {
  const result = optimizeEnergyAllocation(demands, totalSupply);
  return {
    ...result,
    module: 'water',
    explanation: result.explanation.replace(/MW/g, 'ML'),
  };
}
