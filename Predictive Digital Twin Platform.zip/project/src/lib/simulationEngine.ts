import { ZONES } from './zones';
import type { ScenarioParams, ScenarioResult, WeatherCondition } from './types';

export const DEFAULT_SCENARIO: ScenarioParams = {
  trafficMultiplier: 1.0,
  energySupplyChange: 0,
  waterDemandChange: 0,
  weatherScenario: 'clear',
  temperatureOffset: 0,
  signalOptimization: false,
  waterConservation: false,
  loadShedding: 0,
};

const WEATHER_EFFECTS: Record<WeatherCondition, { traffic: number; energy: number; water: number }> = {
  clear: { traffic: 1.0, energy: 1.0, water: 1.0 },
  cloudy: { traffic: 0.95, energy: 0.95, water: 1.0 },
  rain: { traffic: 0.85, energy: 0.98, water: 1.1 },
  storm: { traffic: 0.7, energy: 1.1, water: 1.2 },
  heatwave: { traffic: 1.05, energy: 1.35, water: 1.4 },
};

function trafficForHour(zoneType: string, hour: number, weather: WeatherCondition, multiplier: number, signalOpt: boolean, roadCap: number): number {
  let base = roadCap * 0.45;
  if (zoneType === 'commercial') {
    if (hour >= 7 && hour <= 9) base *= 1.6;
    else if (hour >= 17 && hour <= 19) base *= 1.7;
    else if (hour >= 22 || hour <= 5) base *= 0.2;
  } else if (zoneType === 'residential') {
    if (hour >= 7 && hour <= 9) base *= 1.5;
    else if (hour >= 17 && hour <= 19) base *= 1.3;
    else if (hour >= 22 || hour <= 5) base *= 0.15;
  } else if (zoneType === 'industrial') {
    if (hour >= 6 && hour <= 16) base *= 1.3;
    else if (hour >= 22 || hour <= 4) base *= 0.25;
  } else {
    if (hour >= 6 && hour <= 20) base *= 1.4;
    else base *= 0.5;
  }
  base *= WEATHER_EFFECTS[weather].traffic;
  base *= multiplier;
  if (signalOpt) base *= 0.88;
  return Math.max(5, base);
}

function congestionFromVolume(volume: number, roadCap: number, signalOpt: boolean): number {
  const ratio = volume / roadCap;
  let cong = ratio * 0.7;
  if (signalOpt) cong *= 0.85;
  return Math.max(0, Math.min(1, cong));
}

function energyForHour(zoneType: string, hour: number, temperature: number, weather: WeatherCondition, supply: number): number {
  let base = supply * 0.65;
  if (zoneType === 'residential') {
    if (hour >= 18 && hour <= 22) base *= 2.0;
    else if (hour >= 6 && hour <= 9) base *= 1.6;
    else if (hour >= 0 && hour <= 5) base *= 0.4;
  } else if (zoneType === 'commercial') {
    if (hour >= 9 && hour <= 18) base *= 1.8;
    else if (hour >= 0 && hour <= 5) base *= 0.3;
  } else if (zoneType === 'industrial') {
    if (hour >= 6 && hour <= 20) base *= 1.6;
    else base *= 0.5;
  } else {
    if (hour >= 6 && hour <= 22) base *= 1.4;
    else base *= 0.4;
  }
  if (temperature > 30) base *= 1 + (temperature - 30) * 0.04;
  else if (temperature < 10) base *= 1 + (10 - temperature) * 0.03;
  base *= WEATHER_EFFECTS[weather].energy;
  return Math.max(1, base);
}

function waterForHour(zoneType: string, hour: number, temperature: number, weather: WeatherCondition, pop: number, demandChange: number, conservation: boolean): number {
  let base = pop * 0.0001;
  if (zoneType === 'residential') {
    if (hour >= 6 && hour <= 9) base *= 2.0;
    else if (hour >= 18 && hour <= 21) base *= 2.5;
    else if (hour >= 0 && hour <= 5) base *= 0.3;
  } else if (zoneType === 'commercial') {
    if (hour >= 9 && hour <= 18) base *= 2.5;
    else base *= 0.4;
  } else if (zoneType === 'industrial') {
    if (hour >= 6 && hour <= 20) base *= 1.8;
    else base *= 0.5;
  } else {
    if (hour >= 6 && hour <= 22) base *= 1.5;
    else base *= 0.3;
  }
  if (temperature > 30) base *= 1 + (temperature - 30) * 0.05;
  base *= WEATHER_EFFECTS[weather].water;
  base *= (1 + demandChange / 100);
  if (conservation) base *= 0.85;
  return Math.max(0.5, base);
}

export function runScenario(params: ScenarioParams): ScenarioResult {
  const baselineParams: ScenarioParams = { ...DEFAULT_SCENARIO };
  const hours = Array.from({ length: 24 }, (_, i) => i);
  const labels = hours.map((h) => `${h.toString().padStart(2, '0')}:00`);

  const trafficBaseline: number[] = [];
  const trafficModified: number[] = [];
  const energyBaselineDemand: number[] = [];
  const energyModifiedDemand: number[] = [];
  const energySupply: number[] = [];
  const waterBaselineDemand: number[] = [];
  const waterModifiedDemand: number[] = [];
  const waterSupply: number[] = [];

  for (const h of hours) {
    let tBase = 0, tMod = 0;
    let eBase = 0, eMod = 0, eSup = 0;
    let wBase = 0, wMod = 0, wSup = 0;

    for (const zone of ZONES) {
      const baseVol = trafficForHour(zone.type, h, 'clear', 1.0, false, zone.roadCapacity);
      const modVol = trafficForHour(zone.type, h, params.weatherScenario, params.trafficMultiplier, params.signalOptimization, zone.roadCapacity);
      tBase += congestionFromVolume(baseVol, zone.roadCapacity, false);
      tMod += congestionFromVolume(modVol, zone.roadCapacity, params.signalOptimization);

      const temp = 20 + 8 * Math.sin((h - 6) / 24 * 2 * Math.PI) + params.temperatureOffset;
      eBase += energyForHour(zone.type, h, temp, 'clear', zone.powerSupply);
      const modSupply = zone.powerSupply * (1 + params.energySupplyChange / 100 - params.loadShedding / 100);
      eMod += energyForHour(zone.type, h, temp, params.weatherScenario, modSupply);
      eSup += modSupply;

      wBase += waterForHour(zone.type, h, temp, 'clear', zone.population, 0, false);
      wMod += waterForHour(zone.type, h, temp, params.weatherScenario, zone.population, params.waterDemandChange, params.waterConservation);
      wSup += params.waterConservation ? zone.waterSupply * 0.9 : zone.waterSupply;
    }

    trafficBaseline.push(Math.round((tBase / ZONES.length) * 1000) / 1000);
    trafficModified.push(Math.round((tMod / ZONES.length) * 1000) / 1000);
    energyBaselineDemand.push(Math.round(eBase * 100) / 100);
    energyModifiedDemand.push(Math.round(eMod * 100) / 100);
    energySupply.push(Math.round(eSup * 100) / 100);
    waterBaselineDemand.push(Math.round(wBase * 100) / 100);
    waterModifiedDemand.push(Math.round(wMod * 100) / 100);
    waterSupply.push(Math.round(wSup * 100) / 100);
  }

  const avgTBase = avg(trafficBaseline);
  const avgTMod = avg(trafficModified);
  const avgEBase = avg(energyBaselineDemand);
  const avgEMod = avg(energyModifiedDemand);
  const avgWBase = avg(waterBaselineDemand);
  const avgWMod = avg(waterModifiedDemand);
  const eSupAvg = avg(energySupply);
  const wSupAvg = avg(waterSupply);

  const eGapBase = Math.max(0, avgEBase - eSupAvg);
  const eGapMod = Math.max(0, avgEMod - eSupAvg);
  const wGapBase = Math.max(0, avgWBase - wSupAvg);
  const wGapMod = Math.max(0, avgWMod - wSupAvg);

  return {
    traffic: {
      baseline: trafficBaseline, modified: trafficModified, labels,
      avgBaseline: round2(avgTBase), avgModified: round2(avgTMod),
      riskReduction: round2(Math.max(0, (avgTBase - avgTMod) / (avgTBase || 1) * 100)),
    },
    energy: {
      baselineDemand: energyBaselineDemand, modifiedDemand: energyModifiedDemand, supply: energySupply, labels,
      avgBaseline: round2(avgEBase), avgModified: round2(avgEMod),
      supplyGapBaseline: round2(eGapBase), supplyGapModified: round2(eGapMod),
      riskReduction: round2(eGapBase > 0 ? Math.max(0, (eGapBase - eGapMod) / eGapBase * 100) : 0),
    },
    water: {
      baselineDemand: waterBaselineDemand, modifiedDemand: waterModifiedDemand, supply: waterSupply, labels,
      avgBaseline: round2(avgWBase), avgModified: round2(avgWMod),
      supplyGapBaseline: round2(wGapBase), supplyGapModified: round2(wGapMod),
      riskReduction: round2(wGapBase > 0 ? Math.max(0, (wGapBase - wGapMod) / wGapBase * 100) : 0),
    },
    summary: {
      overallRiskReduction: round2((
        Math.max(0, (avgTBase - avgTMod) / (avgTBase || 1)) +
        (eGapBase > 0 ? Math.max(0, (eGapBase - eGapMod) / eGapBase) : 0) +
        (wGapBase > 0 ? Math.max(0, (wGapBase - wGapMod) / wGapBase) : 0)
      ) / 3 * 100),
      energySavings: round2(Math.max(0, avgEBase - avgEMod)),
      waterSavings: round2(Math.max(0, avgWBase - avgWMod)),
      trafficImprovement: round2(Math.max(0, avgTBase - avgTMod)),
    },
  };
}

function avg(arr: number[]): number {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}
function round2(v: number): number {
  return Math.round(v * 100) / 100;
}
