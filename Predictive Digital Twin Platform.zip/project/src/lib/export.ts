import type { ScenarioResult, RiskAlert, OptimizationResult, ScenarioParams } from './types';

export function exportScenarioCSV(result: ScenarioResult): string {
  const lines: string[] = [];
  lines.push('PROJECT MIRAGE - Simulation Report');
  lines.push(`Generated,${new Date().toISOString()}`);
  lines.push('');
  lines.push('MODULE,HOUR,BASELINE,MODIFIED,SUPPLY_OR_CAPACITY');
  lines.push('--- TRAFFIC (congestion index) ---');
  result.traffic.labels.forEach((label, i) => {
    lines.push(`Traffic,${label},${result.traffic.baseline[i]},${result.traffic.modified[i]},`);
  });
  lines.push('--- ENERGY (demand vs supply) ---');
  result.energy.labels.forEach((label, i) => {
    lines.push(`Energy,${label},${result.energy.baselineDemand[i]},${result.energy.modifiedDemand[i]},${result.energy.supply[i]}`);
  });
  lines.push('--- WATER (demand vs supply) ---');
  result.water.labels.forEach((label, i) => {
    lines.push(`Water,${label},${result.water.baselineDemand[i]},${result.water.modifiedDemand[i]},${result.water.supply[i]}`);
  });
  lines.push('');
  lines.push('SUMMARY METRIC,VALUE');
  lines.push(`Overall Risk Reduction %,${result.summary.overallRiskReduction}`);
  lines.push(`Energy Savings,${result.summary.energySavings}`);
  lines.push(`Water Savings,${result.summary.waterSavings}`);
  lines.push(`Traffic Improvement,${result.summary.trafficImprovement}`);
  return lines.join('\n');
}

export function exportAlertsCSV(alerts: RiskAlert[]): string {
  const lines: string[] = [];
  lines.push('MODULE,ZONE,RISK_LEVEL,RISK_SCORE,CONFIDENCE,PREDICTED_INTERVAL,ACTION');
  for (const a of alerts) {
    lines.push(`${a.module},${a.zoneName},${a.riskLevel},${a.riskScore},${a.confidence},"${a.predictedInterval}","${a.recommendedAction}"`);
  }
  return lines.join('\n');
}

export function exportOptimizationCSV(opt: OptimizationResult): string {
  const lines: string[] = [];
  lines.push('OPTIMIZATION RESULT');
  lines.push(`Module,${opt.module}`);
  lines.push(`Total Resource,${opt.totalResource}`);
  lines.push(`Total Demand,${opt.totalDemand}`);
  lines.push(`Total Unmet,${opt.totalUnmet}`);
  lines.push(`Objective Value,${opt.objectiveValue}`);
  lines.push('');
  lines.push('ZONE,DEMAND,ALLOCATED,UNMET,PRIORITY');
  for (const a of opt.allocation) {
    lines.push(`${a.zoneName},${a.demand},${a.allocated},${a.unmet},${a.priority}`);
  }
  return lines.join('\n');
}

export function exportParamsCSV(params: ScenarioParams): string {
  const lines: string[] = [];
  lines.push('PARAMETER,VALUE');
  lines.push(`Traffic Multiplier,${params.trafficMultiplier}`);
  lines.push(`Energy Supply Change %,${params.energySupplyChange}`);
  lines.push(`Water Demand Change %,${params.waterDemandChange}`);
  lines.push(`Weather Scenario,${params.weatherScenario}`);
  lines.push(`Temperature Offset,${params.temperatureOffset}`);
  lines.push(`Signal Optimization,${params.signalOptimization}`);
  lines.push(`Water Conservation,${params.waterConservation}`);
  lines.push(`Load Shedding %,${params.loadShedding}`);
  return lines.join('\n');
}

export function downloadCSV(content: string, filename: string): void {
  const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadFullReport(
  params: ScenarioParams,
  result: ScenarioResult,
  alerts: RiskAlert[],
  optimization: OptimizationResult | null,
  modelName: string
): void {
  const sections = [
    exportParamsCSV(params),
    '',
    exportScenarioCSV(result),
    '',
    '=== RISK ALERTS ===',
    exportAlertsCSV(alerts),
    optimization ? ['', '=== OPTIMIZATION ===', exportOptimizationCSV(optimization)] : [],
    '',
    `Model: ${modelName}`,
    'Note: Strong performance on synthetic data does not establish real-world predictive accuracy.',
  ];
  downloadCSV(sections.flat().join('\n'), `mirage_report_${Date.now()}.csv`);
}
