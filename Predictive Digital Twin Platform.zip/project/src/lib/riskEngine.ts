import { ZONES } from './zones';
import { predictTraffic, predictEnergy, predictWater } from './predictions';
import type { RiskAlert, RiskLevel, ScenarioParams } from './types';

export interface RiskThresholds {
  traffic: { medium: number; high: number; critical: number };
  energy: { medium: number; high: number; critical: number };
  water: { medium: number; high: number; critical: number };
}

export const DEFAULT_THRESHOLDS: RiskThresholds = {
  traffic: { medium: 0.3, high: 0.5, critical: 0.7 },
  energy: { medium: 0.05, high: 0.15, critical: 0.3 },
  water: { medium: 0.05, high: 0.15, critical: 0.3 },
};

export function classifyRisk(score: number, thresholds: { medium: number; high: number; critical: number }): RiskLevel {
  if (score >= thresholds.critical) return 'critical';
  if (score >= thresholds.high) return 'high';
  if (score >= thresholds.medium) return 'medium';
  return 'low';
}

function confidenceFromSamples(riskScore: number, horizon: number): 'low' | 'moderate' | 'high' {
  if (horizon <= 3) return 'high';
  if (horizon <= 6) return 'moderate';
  return 'low';
}

export function detectRisks(
  params: ScenarioParams,
  thresholds: RiskThresholds = DEFAULT_THRESHOLDS,
  horizon: number = 12
): RiskAlert[] {
  const alerts: RiskAlert[] = [];

  const trafficPreds = predictTraffic(params, horizon);
  for (const p of trafficPreds) {
    if (p.riskLevel === 'low') continue;
    const factors: { name: string; value: string; contribution: string }[] = [];
    const f = p.features;
    if (f.densityRatio > 0.6) factors.push({ name: 'Vehicle Density', value: `${f.densityRatio.toFixed(2)}`, contribution: 'High vehicle-to-capacity ratio increases congestion' });
    if (f.avgSpeed < 30) factors.push({ name: 'Average Speed', value: `${f.avgSpeed.toFixed(1)} km/h`, contribution: 'Low speed indicates flow breakdown' });
    if (params.weatherScenario === 'storm' || params.weatherScenario === 'rain') factors.push({ name: 'Weather', value: params.weatherScenario, contribution: 'Adverse weather reduces road throughput' });
    if (params.trafficMultiplier > 1.0) factors.push({ name: 'Traffic Volume Change', value: `+${Math.round((params.trafficMultiplier - 1) * 100)}%`, contribution: 'Increased demand raises congestion' });

    alerts.push({
      id: `traffic-${p.zoneId}`,
      module: 'traffic',
      zoneId: p.zoneId,
      zoneName: p.zoneName,
      riskLevel: p.riskLevel,
      riskScore: Math.round(p.predictedCongestion * 100) / 100,
      factors: factors.length > 0 ? factors : [{ name: 'Congestion', value: p.predictedCongestion.toFixed(2), contribution: 'Overall congestion above threshold' }],
      predictedInterval: `Next ${horizon} hours`,
      recommendedAction: p.riskLevel === 'critical'
        ? 'Reroute traffic to alternate corridors and adjust signal timing for peak hours'
        : 'Adjust signal timing and monitor for escalation',
      confidence: confidenceFromSamples(p.predictedCongestion, horizon),
    });
  }

  const energyPreds = predictEnergy(params, horizon);
  for (const p of energyPreds) {
    if (p.riskLevel === 'low') continue;
    const factors: { name: string; value: string; contribution: string }[] = [];
    const f = p.features;
    if (p.supplyGap > 0) factors.push({ name: 'Supply Gap', value: `${p.supplyGap.toFixed(2)} MW`, contribution: 'Demand exceeds available supply' });
    if (f.temperature > 30) factors.push({ name: 'Temperature', value: `${f.temperature.toFixed(1)}°C`, contribution: 'High temperature drives cooling demand' });
    if (params.energySupplyChange < 0) factors.push({ name: 'Supply Reduction', value: `${params.energySupplyChange}%`, contribution: 'Reduced supply capacity increases shortage risk' });
    if (params.loadShedding > 0) factors.push({ name: 'Load Shedding', value: `${params.loadShedding}%`, contribution: 'Planned load reduction' });

    alerts.push({
      id: `energy-${p.zoneId}`,
      module: 'energy',
      zoneId: p.zoneId,
      zoneName: p.zoneName,
      riskLevel: p.riskLevel,
      riskScore: Math.round((p.supplyGap / p.supply) * 100) / 100,
      factors: factors.length > 0 ? factors : [{ name: 'Supply Gap', value: p.supplyGap.toFixed(2), contribution: 'Demand-supply imbalance' }],
      predictedInterval: `Next ${horizon} hours`,
      recommendedAction: p.riskLevel === 'critical'
        ? 'Shed non-essential loads and redistribute supply from surplus zones'
        : 'Monitor demand and prepare load-balancing measures',
      confidence: confidenceFromSamples(p.supplyGap / p.supply, horizon),
    });
  }

  const waterPreds = predictWater(params, horizon);
  for (const p of waterPreds) {
    if (p.riskLevel === 'low') continue;
    const factors: { name: string; value: string; contribution: string }[] = [];
    const f = p.features;
    if (p.supplyGap > 0) factors.push({ name: 'Supply Gap', value: `${p.supplyGap.toFixed(2)} ML`, contribution: 'Demand exceeds available water supply' });
    if (params.weatherScenario === 'heatwave') factors.push({ name: 'Weather', value: 'Heatwave', contribution: 'Heatwave increases consumption by ~25%' });
    if (params.waterDemandChange > 0) factors.push({ name: 'Demand Increase', value: `+${params.waterDemandChange}%`, contribution: 'Elevated demand raises shortage risk' });
    if (f.reservoirLevel < 20) factors.push({ name: 'Reservoir Level', value: `${f.reservoirLevel.toFixed(1)}%`, contribution: 'Low reservoir reserves' });

    alerts.push({
      id: `water-${p.zoneId}`,
      module: 'water',
      zoneId: p.zoneId,
      zoneName: p.zoneName,
      riskLevel: p.riskLevel,
      riskScore: Math.round((p.supplyGap / p.supply) * 100) / 100,
      factors: factors.length > 0 ? factors : [{ name: 'Supply Gap', value: p.supplyGap.toFixed(2), contribution: 'Demand-supply imbalance' }],
      predictedInterval: `Next ${horizon} hours`,
      recommendedAction: p.riskLevel === 'critical'
        ? 'Implement water conservation measures and redistribute supply from surplus zones'
        : 'Monitor consumption and prepare conservation protocols',
      confidence: confidenceFromSamples(p.supplyGap / p.supply, horizon),
    });
  }

  const order: Record<RiskLevel, number> = { critical: 0, high: 1, medium: 2, low: 3 };
  alerts.sort((a, b) => order[a.riskLevel] - order[b.riskLevel]);
  return alerts;
}

export function generateExplanation(
  module: 'traffic' | 'energy' | 'water',
  zoneId: string,
  params: ScenarioParams,
  featureImportance: { feature: string; importance: number }[]
): string {
  const topFeatures = featureImportance.slice(0, 3);
  const zone = ZONES.find((z) => z.id === zoneId);

  const parts: string[] = [];
  for (const f of topFeatures) {
    if (f.importance < 0.01) continue;
    let desc = '';
    switch (f.feature) {
      case 'vehicleCount':
        desc = `Vehicle count (importance: ${(f.importance * 100).toFixed(1)}%) directly drives congestion — more vehicles mean denser roads.`;
        break;
      case 'densityRatio':
        desc = `Vehicle-to-capacity ratio (importance: ${(f.importance * 100).toFixed(1)}%) is the strongest predictor of flow breakdown.`;
        break;
      case 'avgSpeed':
        desc = `Average speed (importance: ${(f.importance * 100).toFixed(1)}%) inversely correlates with congestion — lower speed means higher congestion.`;
        break;
      case 'temperature':
        desc = `Temperature (importance: ${(f.importance * 100).toFixed(1)}%) affects demand — extreme heat or cold increases consumption.`;
        break;
      case 'hour':
        desc = `Time of day (importance: ${(f.importance * 100).toFixed(1)}%) captures daily demand patterns and rush-hour peaks.`;
        break;
      case 'dayOfWeek':
        desc = `Day of week (importance: ${(f.importance * 100).toFixed(1)}%) distinguishes weekday vs weekend patterns.`;
        break;
      case 'historicalDemand':
        desc = `Historical demand (importance: ${(f.importance * 100).toFixed(1)}%) provides a baseline for current predictions.`;
        break;
      case 'supply':
        desc = `Available supply (importance: ${(f.importance * 100).toFixed(1)}%) determines the gap between demand and capacity.`;
        break;
      case 'weather':
        desc = `Weather conditions (importance: ${(f.importance * 100).toFixed(1)}%) modify both demand and system capacity.`;
        break;
      case 'population':
        desc = `Population (importance: ${(f.importance * 100).toFixed(1)}%) scales base consumption for the zone.`;
        break;
      case 'reservoirLevel':
        desc = `Reservoir level (importance: ${(f.importance * 100).toFixed(1)}%) indicates available water reserves.`;
        break;
      case 'zoneType':
        desc = `Zone type (importance: ${(f.importance * 100).toFixed(1)}%) captures different usage patterns by zone classification.`;
        break;
      case 'roadCapacity':
        desc = `Road capacity (importance: ${(f.importance * 100).toFixed(1)}%) sets the upper bound for vehicle throughput.`;
        break;
      default:
        desc = `${f.feature} (importance: ${(f.importance * 100).toFixed(1)}%) contributes to the prediction.`;
    }
    parts.push(desc);
  }

  const moduleLabel = module === 'traffic' ? 'traffic congestion' : module === 'energy' ? 'electricity demand' : 'water demand';
  const scenarioNote = params.weatherScenario !== 'clear' ? ` The ${params.weatherScenario} scenario amplifies ${moduleLabel} based on its weather effect coefficient.` : '';

  return `Prediction for ${zone?.name || zoneId} is driven by: ${parts.join(' ')}.${scenarioNote} These features were ranked by their measured importance in the Random Forest model trained on ${21} days of synthetic data.`;
}
