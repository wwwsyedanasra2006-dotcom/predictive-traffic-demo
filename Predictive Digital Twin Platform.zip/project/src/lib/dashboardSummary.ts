import { ZONES } from './zones';
import { predictTraffic, predictEnergy, predictWater } from './predictions';
import { DEFAULT_SCENARIO } from './simulationEngine';
import { DEFAULT_THRESHOLDS, classifyRisk } from './riskEngine';
import type { DashboardSummary, ScenarioParams } from './types';

export function getDashboardSummary(params: ScenarioParams = DEFAULT_SCENARIO): DashboardSummary {
  const trafficPreds = predictTraffic(params, 6);
  const energyPreds = predictEnergy(params, 6);
  const waterPreds = predictWater(params, 6);

  const avgCongestion = trafficPreds.reduce((s, p) => s + p.predictedCongestion, 0) / trafficPreds.length;
  const avgEnergyDemand = energyPreds.reduce((s, p) => s + p.predictedDemand, 0) / energyPreds.length;
  const avgEnergySupply = energyPreds.reduce((s, p) => s + p.supply, 0) / energyPreds.length;
  const energyGap = energyPreds.reduce((s, p) => s + Math.max(0, p.supplyGap), 0) / energyPreds.length;
  const avgWaterDemand = waterPreds.reduce((s, p) => s + p.predictedDemand, 0) / waterPreds.length;
  const avgWaterSupply = waterPreds.reduce((s, p) => s + p.supply, 0) / waterPreds.length;
  const waterGap = waterPreds.reduce((s, p) => s + Math.max(0, p.supplyGap), 0) / waterPreds.length;

  const highRiskTraffic = trafficPreds.filter((p) =>
    classifyRisk(p.predictedCongestion, DEFAULT_THRESHOLDS.traffic) === 'high' ||
    classifyRisk(p.predictedCongestion, DEFAULT_THRESHOLDS.traffic) === 'critical'
  ).length;
  const highRiskEnergy = energyPreds.filter((p) =>
    classifyRisk(p.supplyGap > 0 ? p.supplyGap / p.supply : 0, DEFAULT_THRESHOLDS.energy) === 'high' ||
    classifyRisk(p.supplyGap > 0 ? p.supplyGap / p.supply : 0, DEFAULT_THRESHOLDS.energy) === 'critical'
  ).length;
  const highRiskWater = waterPreds.filter((p) =>
    classifyRisk(p.supplyGap > 0 ? p.supplyGap / p.supply : 0, DEFAULT_THRESHOLDS.water) === 'high' ||
    classifyRisk(p.supplyGap > 0 ? p.supplyGap / p.supply : 0, DEFAULT_THRESHOLDS.water) === 'critical'
  ).length;

  const activeAlerts = highRiskTraffic + highRiskEnergy + highRiskWater;
  const criticalAlerts = trafficPreds.filter((p) => p.riskLevel === 'critical').length +
    energyPreds.filter((p) => p.riskLevel === 'critical').length +
    waterPreds.filter((p) => p.riskLevel === 'critical').length;

  return {
    totalZones: ZONES.length,
    traffic: {
      avgCongestion: Math.round(avgCongestion * 1000) / 1000,
      highRiskZones: highRiskTraffic,
    },
    energy: {
      avgDemand: Math.round(avgEnergyDemand * 100) / 100,
      avgSupply: Math.round(avgEnergySupply * 100) / 100,
      supplyGap: Math.round(energyGap * 100) / 100,
      highRiskZones: highRiskEnergy,
    },
    water: {
      avgDemand: Math.round(avgWaterDemand * 100) / 100,
      avgSupply: Math.round(avgWaterSupply * 100) / 100,
      supplyGap: Math.round(waterGap * 100) / 100,
      highRiskZones: highRiskWater,
    },
    activeAlerts,
    criticalAlerts,
    simulationTime: new Date().toLocaleString(),
    zones: ZONES,
  };
}
