/*
# Create simulation_history table for PROJECT MIRAGE

1. New Tables
- `simulation_history`
  - `id` (uuid, primary key)
  - `name` (text, name of the saved simulation run)
  - `module` (text, which module: traffic, energy, water, or combined)
  - `scenario_params` (jsonb, the what-if scenario parameters used)
  - `baseline_results` (jsonb, results before scenario changes)
  - `modified_results` (jsonb, results after scenario changes)
  - `risk_alerts` (jsonb, risk alerts generated)
  - `optimization_result` (jsonb, optimization results if applicable)
  - `notes` (text, user notes)
  - `created_at` (timestamp, auto)

2. Security
- Enable RLS on `simulation_history`.
- Allow anon + authenticated CRUD because this is a single-tenant demo app with no sign-in.
*/

CREATE TABLE IF NOT EXISTS simulation_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  module text NOT NULL DEFAULT 'combined',
  scenario_params jsonb NOT NULL DEFAULT '{}'::jsonb,
  baseline_results jsonb NOT NULL DEFAULT '{}'::jsonb,
  modified_results jsonb NOT NULL DEFAULT '{}'::jsonb,
  risk_alerts jsonb NOT NULL DEFAULT '[]'::jsonb,
  optimization_result jsonb DEFAULT null,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE simulation_history ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_simulations" ON simulation_history;
CREATE POLICY "anon_select_simulations" ON simulation_history FOR SELECT
TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_simulations" ON simulation_history;
CREATE POLICY "anon_insert_simulations" ON simulation_history FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_simulations" ON simulation_history;
CREATE POLICY "anon_update_simulations" ON simulation_history FOR UPDATE
TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_simulations" ON simulation_history;
CREATE POLICY "anon_delete_simulations" ON simulation_history FOR DELETE
TO anon, authenticated USING (true);
